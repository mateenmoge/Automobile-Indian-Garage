import React from 'react';
import { Bell } from 'lucide-react';
import { AppProvider, useApp } from './context/AppContext';
import HomePage from './pages/HomePage';
import AuthPage from './pages/AuthPage';
import ProfilePage from './pages/ProfilePage';
import UserDashboard from './pages/user/UserDashboard';
import BookingPage from './pages/user/BookingPage';
import TrackingPage from './pages/user/TrackingPage';
import HistoryPage from './pages/user/HistoryPage';
import ReviewsPage from './pages/user/ReviewsPage';
import MechanicDashboard from './pages/mechanic/MechanicDashboard';
import JobRequestsPage from './pages/mechanic/JobRequestsPage';
import KhataPage from './pages/mechanic/KhataPage';
import Sidebar from './components/layout/Sidebar';
import Toast from './components/ui/Toast';

const PlaceholderPage: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => (
  <div className="p-6">
    <div className="dash-card text-center py-16">
      <div className="text-5xl mb-4">🚧</div>
      <h1 className="text-2xl font-black text-white mb-2">{title}</h1>
      <p className="text-slate-400">{subtitle || 'This page will be available in the next build.'}</p>
    </div>
  </div>
);

const NotificationsPage: React.FC = () => {
  const { notifications, currentUser, markNotificationRead } = useApp();
  const myNotifications = notifications.filter(n => n.userId === currentUser?.id);

  return (
    <div className="p-6 space-y-4 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <Bell size={22} className="text-orange-400" /> Notifications
        </h1>
        <p className="text-slate-400 text-sm mt-1">Recent updates for your account</p>
      </div>

      {myNotifications.length === 0 ? (
        <div className="dash-card text-center py-16">
          <div className="text-5xl mb-4">🔔</div>
          <p className="text-slate-400">No notifications yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {myNotifications.map(n => (
            <div key={n.id} className={`dash-card border ${n.read ? 'border-slate-800' : 'border-orange-500/30'}`}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-white font-bold">{n.title}</div>
                  <div className="text-slate-400 text-sm mt-1">{n.message}</div>
                  <div className="text-slate-500 text-xs mt-2">{new Date(n.createdAt).toLocaleString('en-IN')}</div>
                </div>
                {!n.read && (
                  <button onClick={() => markNotificationRead(n.id)} className="btn-secondary text-xs px-3 py-1.5">
                    Mark read
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const DashboardRouter: React.FC = () => {
  const { activeTab, currentUser, toastMessage, toastType, showToast } = useApp();

  const renderUserPage = () => {
    switch (activeTab) {
      case 'dashboard':
        return <UserDashboard />;
      case 'booking':
        return <BookingPage />;
      case 'tracking':
        return <TrackingPage />;
      case 'history':
        return <HistoryPage />;
      case 'reviews':
        return <ReviewsPage />;
      case 'profile':
        return <ProfilePage />;
      case 'notifications':
        return <NotificationsPage />;
      default:
        return <UserDashboard />;
    }
  };

  const renderMechanicPage = () => {
    switch (activeTab) {
      case 'dashboard':
        return <MechanicDashboard />;
      case 'requests':
        return <JobRequestsPage />;
      case 'tracking':
        return <TrackingPage />;
      case 'khata':
        return <KhataPage />;
      case 'history':
        return <HistoryPage />;
      case 'reviews':
        return <ReviewsPage />;
      case 'profile':
        return <ProfilePage />;
      case 'notifications':
        return <NotificationsPage />;
      default:
        return <MechanicDashboard />;
    }
  };

  const renderAdminPage = () => {
    switch (activeTab) {
      case 'dashboard':
        return <PlaceholderPage title="Admin Dashboard" subtitle="Admin analytics and management screens will go here." />;
      case 'users':
        return <PlaceholderPage title="Users" subtitle="Manage registered users here." />;
      case 'mechanics':
        return <PlaceholderPage title="Mechanics" subtitle="Manage mechanics here." />;
      case 'bookings-admin':
        return <PlaceholderPage title="All Bookings" subtitle="View all bookings here." />;
      case 'analytics':
        return <PlaceholderPage title="Analytics" subtitle="Charts and reports will go here." />;
      case 'reports':
        return <PlaceholderPage title="Reports" subtitle="Customer issues and reports will go here." />;
      case 'settings':
        return <PlaceholderPage title="Settings" subtitle="Admin settings will go here." />;
      default:
        return <PlaceholderPage title="Admin Dashboard" subtitle="Admin analytics and management screens will go here." />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      <Sidebar />
      <main className="flex-1 min-w-0 bg-slate-950">
        {currentUser?.role === 'mechanic'
          ? renderMechanicPage()
          : currentUser?.role === 'admin'
            ? renderAdminPage()
            : renderUserPage()}
      </main>

      {toastMessage && (
        <Toast
          message={toastMessage}
          type={toastType}
          onClose={() => showToast('', 'info')}
        />
      )}
    </div>
  );
};

const AppShell: React.FC = () => {
  const { activeTab, isLoggedIn } = useApp();

  if (!isLoggedIn) {
    switch (activeTab) {
      case 'auth':
        return <AuthPage />;
      case 'home':
      default:
        return <HomePage />;
    }
  }

  if (activeTab === 'home') {
    return <HomePage />;
  }

  return <DashboardRouter />;
};

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
