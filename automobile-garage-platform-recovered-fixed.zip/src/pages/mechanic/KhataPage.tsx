import React, { useState } from 'react';
import { Plus, TrendingUp, TrendingDown, BookOpen, Check, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';

const KhataPage: React.FC = () => {
  const { khataEntries, addKhataEntry, showToast } = useApp();
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    type: 'credit' as 'credit' | 'debit',
    amount: '',
    description: '',
    customerName: '',
    paid: true,
  });

  const myEntries = khataEntries.filter(k => k.mechanicId === 'mech1');
  const totalCredit = myEntries.filter(e => e.type === 'credit' && e.paid).reduce((s, e) => s + e.amount, 0);
  const totalDebit  = myEntries.filter(e => e.type === 'debit').reduce((s, e) => s + e.amount, 0);
  const totalDue    = myEntries.filter(e => e.type === 'credit' && !e.paid).reduce((s, e) => s + e.amount, 0);
  const netBalance  = totalCredit - totalDebit;

  const handleAdd = () => {
    if (!form.amount || !form.description || !form.customerName) {
      showToast('Please fill all fields', 'error'); return;
    }
    addKhataEntry({
      mechanicId:   'mech1',
      type:          form.type,
      amount:        Number(form.amount),
      description:   form.description,
      customerName:  form.customerName,
      date:          new Date().toISOString().slice(0, 10),
      paid:          form.paid,
    });
    showToast('Entry added to Khata!', 'success');
    setShowAdd(false);
    setForm({ type: 'credit', amount: '', description: '', customerName: '', paid: true });
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <BookOpen size={24} className="text-orange-400" /> Digital Khata Book
          </h1>
          <p className="text-slate-400 text-sm mt-1">Track your earnings and dues</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="btn-primary">
          <Plus size={16} /> Add Entry
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Net Balance',   value: `Rs.${netBalance.toLocaleString()}`,   color: 'from-green-500 to-green-600', icon: '💰' },
          { label: 'Total Earned',  value: `Rs.${totalCredit.toLocaleString()}`,  color: 'from-blue-500 to-blue-600',   icon: '📈' },
          { label: 'Total Spent',   value: `Rs.${totalDebit.toLocaleString()}`,   color: 'from-red-500 to-red-600',     icon: '📉' },
          { label: 'Dues Pending',  value: `Rs.${totalDue.toLocaleString()}`,     color: 'from-yellow-500 to-yellow-600', icon: '⏳' },
        ].map(card => (
          <div key={card.label} className="dash-card card-hover">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center text-lg mb-3`}>
              {card.icon}
            </div>
            <div className="text-xl font-black text-white">{card.value}</div>
            <div className="text-slate-400 text-xs mt-0.5">{card.label}</div>
          </div>
        ))}
      </div>

      {/* Add Entry Form */}
      {showAdd && (
        <div className="dash-card border border-orange-500/20 space-y-4 animate-fade-in">
          <h3 className="text-white font-bold">New Khata Entry</h3>
          <div className="grid grid-cols-2 gap-3">
            {(['credit', 'debit'] as const).map(t => (
              <button
                key={t}
                onClick={() => setForm(f => ({ ...f, type: t }))}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border-2 font-semibold text-sm transition-all capitalize ${
                  form.type === t
                    ? t === 'credit' ? 'border-green-500 bg-green-500/10 text-green-300' : 'border-red-500 bg-red-500/10 text-red-300'
                    : 'border-slate-700 text-slate-400'
                }`}
              >
                {t === 'credit' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                {t === 'credit' ? 'Income (Credit)' : 'Expense (Debit)'}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 text-xs mb-1.5 block">Amount (Rs.) *</label>
              <input type="number" className="input-dark text-sm" placeholder="500" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1.5 block">Customer/Party Name *</label>
              <input className="input-dark text-sm" placeholder="e.g. Rahul Sharma" value={form.customerName} onChange={e => setForm(f => ({ ...f, customerName: e.target.value }))} />
            </div>
            <div className="sm:col-span-2">
              <label className="text-slate-400 text-xs mb-1.5 block">Description *</label>
              <input className="input-dark text-sm" placeholder="e.g. Tyre puncture - WagonR" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
            </div>
          </div>
          {form.type === 'credit' && (
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={form.paid}
                onChange={e => setForm(f => ({ ...f, paid: e.target.checked }))}
                className="w-4 h-4 accent-orange-500"
              />
              <span className="text-slate-300 text-sm">Payment received (uncheck if due)</span>
            </label>
          )}
          <div className="flex gap-3">
            <button onClick={handleAdd} className="btn-success flex-1 justify-center">
              <Check size={16} /> Save Entry
            </button>
            <button onClick={() => setShowAdd(false)} className="btn-secondary flex-1 justify-center">
              <X size={16} /> Cancel
            </button>
          </div>
        </div>
      )}

      {/* Entries Table */}
      <div className="dash-card !p-0 overflow-hidden">
        <div className="p-4 border-b border-slate-800">
          <h3 className="text-white font-bold">Transaction History</h3>
        </div>
        <div className="divide-y divide-slate-800">
          {myEntries.map(entry => (
            <div key={entry.id} className="flex items-center gap-4 p-4 hover:bg-slate-800/50 transition-colors">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                entry.type === 'credit' ? 'bg-green-500/10' : 'bg-red-500/10'
              }`}>
                {entry.type === 'credit'
                  ? <TrendingUp size={18} className="text-green-400" />
                  : <TrendingDown size={18} className="text-red-400" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-white font-semibold text-sm truncate">{entry.description}</div>
                <div className="text-slate-400 text-xs">{entry.customerName} • {entry.date}</div>
              </div>
              <div className="flex items-center gap-3">
                {!entry.paid && entry.type === 'credit' && (
                  <span className="text-xs bg-yellow-500/15 text-yellow-400 border border-yellow-500/30 px-2 py-0.5 rounded-full">Due</span>
                )}
                {entry.paid && entry.type === 'credit' && (
                  <span className="text-xs bg-green-500/15 text-green-400 border border-green-500/30 px-2 py-0.5 rounded-full">Paid</span>
                )}
                <span className={`font-bold text-lg ${entry.type === 'credit' ? 'text-green-400' : 'text-red-400'}`}>
                  {entry.type === 'credit' ? '+' : '-'} Rs.{entry.amount}
                </span>
              </div>
            </div>
          ))}
          {myEntries.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <BookOpen size={32} className="mx-auto mb-2 opacity-30" />
              <p>No entries yet. Add your first entry!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default KhataPage;
