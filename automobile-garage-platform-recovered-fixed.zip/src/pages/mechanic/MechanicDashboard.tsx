import React from 'react';
import { TrendingUp, CheckCircle, Clock, Star, Zap, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MECHANICS, MONTHLY_EARNINGS } from '../../data/mockData';
import StatusBadge from '../../components/ui/StatusBadge';

const MechanicDashboard: React.FC = () => {
  const { currentUser, bookings, mechanics, updateMechanicStatus, acceptBooking } = useApp();

  const myMechanic = MECHANICS.find(m => m.id === 'mech1') || MECHANICS[0];
  const myBookings = bookings.filter(b => b.mechanicId === myMechanic.id || b.mechanicId === 'mech1');
  const pendingJobs = myBookings.filter(b => b.status === 'pending');
  const activeJob   = myBookings.find(b => ['accepted','travelling','arrived','in_progress'].includes(b.status));
  const completedJobs = myBookings.filter(b => b.status === 'completed');
  const todayEarnings = completedJobs.filter(b => {
    const d = new Date(b.completedAt || '');
    const t = new Date();
    return d.toDateString() === t.toDateString();
  }).reduce((s, b) => s + b.amount, 0);
  const totalEarnings = completedJobs.reduce((s, b) => s + b.amount, 0);

  const mechStatus = mechanics.find(m => m.id === myMechanic.id)?.status || myMechanic.status;

  const maxEarning = Math.max(...MONTHLY_EARNINGS.map(e => e.earnings));

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-white">
            Welcome, {currentUser?.name?.split(' ')[0]} 👨‍🔧
          </h1>
          <p className="text-slate-400 text-sm mt-0.5">
            {myMechanic.location.address} • {myMechanic.experience} yrs experience
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold border ${
            mechStatus === 'available' ? 'text-green-400 bg-green-500/10 border-green-500/30' :
            mechStatus === 'busy' ? 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30' :
            'text-slate-400 bg-slate-500/10 border-slate-500/30'
          }`}>
            <span className={`w-2 h-2 rounded-full animate-pulse ${
              mechStatus === 'available' ? 'bg-green-400' : mechStatus === 'busy' ? 'bg-yellow-400' : 'bg-slate-400'
            }`} />
            {mechStatus}
          </div>
          <select
            className="input-dark text-sm py-1.5"
            style={{ width: 'auto' }}
            value={mechStatus}
            onChange={e => updateMechanicStatus(myMechanic.id, e.target.value as any)}
          >
            <option value="available">Set Available</option>
            <option value="busy">Set Busy</option>
            <option value="offline">Go Offline</option>
          </select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Today's Earnings", value: `Rs.${todayEarnings}`, icon: '💰', color: 'from-green-500 to-green-600' },
          { label: 'Total Earnings',   value: `Rs.${(totalEarnings + 15420).toLocaleString()}`, icon: '📈', color: 'from-blue-500 to-blue-600' },
          { label: 'Jobs Completed',   value: String(myMechanic.completedJobs), icon: '✅', color: 'from-orange-500 to-orange-600' },
          { label: 'Rating',           value: `${myMechanic.rating} ⭐`, icon: '⭐', color: 'from-yellow-500 to-yellow-600' },
        ].map(stat => (
          <div key={stat.label} className="dash-card card-hover">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-lg mb-3`}>
              {stat.icon}
            </div>
            <div className="text-xl font-black text-white">{stat.value}</div>
            <div className="text-slate-400 text-xs mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Requests */}
        <div className="dash-card">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle size={16} className="text-orange-400" />
            <h2 className="text-white font-bold">New Requests</h2>
            {pendingJobs.length > 0 && (
              <span className="ml-auto bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full font-bold animate-pulse">
                {pendingJobs.length}
              </span>
            )}
          </div>
          <div className="space-y-3">
            {pendingJobs.map(job => (
              <div key={job.id} className="p-4 bg-slate-800 rounded-2xl border border-orange-500/20">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="text-white font-bold">{job.issueType}</div>
                    <div className="text-slate-400 text-sm">{job.userName} • {job.vehicleBrand}</div>
                  </div>
                  <StatusBadge status="pending" pulse />
                </div>
                <div className="text-slate-500 text-xs mb-3 flex items-center gap-2">
                  <Clock size={10} />
                  {new Date(job.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                  <span>•</span>
                  <span>Est: Rs.{job.estimatedAmount}</span>
                </div>
                {job.issueDescription && (
                  <p className="text-slate-400 text-xs mb-3 bg-slate-900 p-2 rounded-xl">
                    "{job.issueDescription}"
                  </p>
                )}
                <div className="flex gap-2">
                  <button onClick={() => acceptBooking(job.id)} className="btn-success flex-1 justify-center text-sm">
                    <CheckCircle size={14} /> Accept
                  </button>
                  <button className="btn-danger flex-1 justify-center text-sm">
                    ✕ Decline
                  </button>
                </div>
              </div>
            ))}
            {pendingJobs.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                <Zap size={28} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">No pending requests</p>
                <p className="text-xs mt-1">Make sure you're set to "Available"</p>
              </div>
            )}
          </div>
        </div>

        {/* Active Job */}
        <div className="space-y-4">
          <div className="dash-card">
            <h2 className="text-white font-bold mb-4 flex items-center gap-2">
              <TrendingUp size={16} className="text-orange-400" /> Active Job
            </h2>
            {activeJob ? (
              <div className="space-y-3">
                <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-white font-bold">{activeJob.issueType}</div>
                    <StatusBadge status={activeJob.status as any} pulse />
                  </div>
                  <div className="text-slate-400 text-sm">{activeJob.userName}</div>
                  <div className="text-slate-500 text-xs mt-1">{activeJob.location}</div>
                  <div className="mt-3 pt-3 border-t border-slate-700 flex items-center justify-between">
                    <span className="text-slate-400 text-sm">Est. Earnings</span>
                    <span className="text-green-400 font-bold">Rs.{activeJob.estimatedAmount}</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button className="btn-success text-sm justify-center">📞 Call Customer</button>
                  <button className="btn-primary text-sm justify-center">🗺️ Navigate</button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                <CheckCircle size={28} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">No active job right now</p>
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="dash-card">
            <div className="flex items-center gap-2 mb-3">
              <Star size={16} className="text-yellow-400" />
              <h3 className="text-white font-bold">Reputation</h3>
            </div>
            <div className="space-y-3">
              {[
                { label: 'Rating', value: `${myMechanic.rating}/5`, bar: (myMechanic.rating / 5) * 100, color: 'bg-yellow-400' },
                { label: 'Response Rate', value: '97%', bar: 97, color: 'bg-green-400' },
                { label: 'Completion Rate', value: '96%', bar: 96, color: 'bg-blue-400' },
              ].map(item => (
                <div key={item.label}>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>{item.label}</span>
                    <span className="text-white font-semibold">{item.value}</span>
                  </div>
                  <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div className={`h-full ${item.color} rounded-full transition-all`} style={{ width: `${item.bar}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Earnings Chart */}
      <div className="dash-card">
        <h2 className="text-white font-bold mb-5 flex items-center gap-2">
          <TrendingUp size={16} className="text-orange-400" /> Monthly Earnings (Last 6 Months)
        </h2>
        <div className="flex items-end gap-3 h-36">
          {MONTHLY_EARNINGS.map(m => (
            <div key={m.month} className="flex-1 flex flex-col items-center gap-2">
              <div className="text-xs text-slate-400 font-semibold">Rs.{(m.earnings / 1000).toFixed(0)}k</div>
              <div
                className="w-full rounded-t-xl bg-gradient-to-t from-orange-600 to-orange-400 min-h-[8px] transition-all hover:opacity-80 cursor-default"
                style={{ height: `${(m.earnings / maxEarning) * 100}px` }}
                title={`${m.month}: Rs.${m.earnings} • ${m.jobs} jobs`}
              />
              <div className="text-xs text-slate-500 font-medium">{m.month}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MechanicDashboard;
