import React from 'react';
import { Clock, MapPin, CheckCircle, X, Phone } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import StatusBadge from '../../components/ui/StatusBadge';

const JobRequestsPage: React.FC = () => {
  const { bookings, acceptBooking, updateBookingStatus, showToast } = useApp();

  const allJobs = bookings.filter(b => b.mechanicId === 'mech1');
  const pending  = allJobs.filter(b => b.status === 'pending');
  const active   = allJobs.filter(b => ['accepted','travelling','arrived','in_progress'].includes(b.status));
  const done     = allJobs.filter(b => ['completed','cancelled'].includes(b.status));

  const handleDecline = (id: string) => {
    updateBookingStatus(id, 'cancelled');
    showToast('Job declined', 'info');
  };

  const JobCard = ({ job, showActions }: { job: typeof allJobs[0]; showActions?: boolean }) => (
    <div className="dash-card border border-slate-700 space-y-3">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-white font-bold">{job.issueType}</div>
          <div className="text-slate-400 text-sm">{job.userName} • {job.vehicleBrand}</div>
        </div>
        <StatusBadge status={job.status as any} pulse={job.status === 'pending'} />
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
        <span className="flex items-center gap-1"><Clock size={10} /> {new Date(job.createdAt).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</span>
        <span className="flex items-center gap-1"><MapPin size={10} /> {job.location}</span>
        <span>💰 Rs.{job.estimatedAmount} (est.)</span>
        <span>🚗 {job.vehicleType}</span>
      </div>
      {job.issueDescription && (
        <div className="bg-slate-800 rounded-xl p-3 text-slate-400 text-xs">
          <span className="text-slate-500 text-xs">Customer says: </span>
          "{job.issueDescription}"
        </div>
      )}
      {showActions && job.status === 'pending' && (
        <div className="flex gap-2 pt-1">
          <button onClick={() => acceptBooking(job.id)} className="btn-success flex-1 justify-center text-sm">
            <CheckCircle size={14} /> Accept Job
          </button>
          <button onClick={() => handleDecline(job.id)} className="btn-danger flex-1 justify-center text-sm">
            <X size={14} /> Decline
          </button>
          <button className="btn-secondary px-3 text-sm">
            <Phone size={14} />
          </button>
        </div>
      )}
      {showActions && ['accepted','travelling','in_progress'].includes(job.status) && (
        <div className="flex gap-2 pt-1">
          {job.status === 'accepted' && (
            <button onClick={() => updateBookingStatus(job.id, 'travelling')} className="btn-primary flex-1 justify-center text-sm">
              🚗 Start Travelling
            </button>
          )}
          {job.status === 'travelling' && (
            <button onClick={() => updateBookingStatus(job.id, 'arrived')} className="btn-primary flex-1 justify-center text-sm">
              📍 Mark Arrived
            </button>
          )}
          {job.status === 'arrived' && (
            <button onClick={() => updateBookingStatus(job.id, 'in_progress')} className="btn-primary flex-1 justify-center text-sm">
              🔧 Start Service
            </button>
          )}
          {job.status === 'in_progress' && (
            <button onClick={() => updateBookingStatus(job.id, 'completed')} className="btn-success flex-1 justify-center text-sm">
              ✅ Mark Complete
            </button>
          )}
          <button className="btn-secondary px-3 text-sm">
            <Phone size={14} />
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-white">Job Requests</h1>
        <p className="text-slate-400 text-sm mt-1">Manage your incoming and active jobs</p>
      </div>

      {/* Pending Requests */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <h2 className="text-white font-bold">Pending Requests</h2>
          {pending.length > 0 && (
            <span className="bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full font-bold animate-pulse">{pending.length}</span>
          )}
        </div>
        <div className="space-y-3">
          {pending.map(job => <JobCard key={job.id} job={job} showActions />)}
          {pending.length === 0 && (
            <div className="dash-card text-center py-8 text-slate-500">
              <p>No pending requests right now</p>
            </div>
          )}
        </div>
      </div>

      {/* Active Jobs */}
      {active.length > 0 && (
        <div>
          <h2 className="text-white font-bold mb-3">Active Jobs</h2>
          <div className="space-y-3">
            {active.map(job => <JobCard key={job.id} job={job} showActions />)}
          </div>
        </div>
      )}

      {/* Completed */}
      {done.length > 0 && (
        <div>
          <h2 className="text-white font-bold mb-3">Completed / Cancelled</h2>
          <div className="space-y-3">
            {done.slice(0, 5).map(job => <JobCard key={job.id} job={job} />)}
          </div>
        </div>
      )}
    </div>
  );
};

export default JobRequestsPage;
