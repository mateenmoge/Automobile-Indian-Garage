import React, { useState, useRef, useEffect } from 'react';
import {
  MapPin, Search, Clock, Bot, Send, Loader, Calendar, Zap,
  CheckCircle, ChevronRight, Filter, Phone
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MECHANICS, VEHICLE_ISSUES, AI_SUGGESTIONS } from '../../data/mockData';
import type { Mechanic } from '../../data/mockData';
import StarRating from '../../components/ui/StarRating';
import StatusBadge from '../../components/ui/StatusBadge';

type Step = 1 | 2 | 3 | 4;

const BookingPage: React.FC = () => {
  const { currentUser, createBooking, showToast, setActiveTab } = useApp();

  const [step, setStep] = useState<Step>(1);
  const [selectedIssue, setSelectedIssue] = useState('');
  const [selectedMechanic, setSelectedMechanic] = useState<Mechanic | null>(null);
  const [bookingType, setBookingType]   = useState<'instant' | 'scheduled'>('instant');
  const [scheduledTime, setScheduledTime] = useState('');
  const [vehicleType, setVehicleType]   = useState('car');
  const [vehicleBrand, setVehicleBrand] = useState('');
  const [issueDescription, setIssueDescription] = useState('');
  const [filterRating, setFilterRating] = useState(0);
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchMech, setSearchMech]     = useState('');
  const [bookingDone, setBookingDone]   = useState(false);
  const [createdId, setCreatedId]       = useState('');

  const [aiMessages, setAiMessages] = useState<{ role: 'user' | 'ai'; text: string }[]>([
    { role: 'ai', text: "Hi! I'm your AI mechanic assistant 🤖 Tell me about your vehicle problem and I'll find the best mechanic near you!" }
  ]);
  const [aiInput, setAiInput]   = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiMessages]);

  const issueData = VEHICLE_ISSUES.find(i => i.id === selectedIssue);

  const filteredMechanics = MECHANICS.filter(m => {
    if (filterStatus !== 'all' && m.status !== filterStatus) return false;
    if (filterRating > 0 && m.rating < filterRating) return false;
    if (searchMech && !m.name.toLowerCase().includes(searchMech.toLowerCase())) return false;
    return true;
  }).sort((a, b) => a.distance - b.distance);

  const sendAiMessage = async () => {
    const msg = aiInput.trim();
    if (!msg) return;
    setAiMessages(m => [...m, { role: 'user', text: msg }]);
    setAiInput('');
    setAiLoading(true);

    await new Promise(r => setTimeout(r, 1100));

    const lower = msg.toLowerCase();
    let responses = AI_SUGGESTIONS.default;
    if (lower.includes('tyre') || lower.includes('puncture')) responses = AI_SUGGESTIONS.flat_tyre;
    else if (lower.includes('engine') || lower.includes('start')) responses = AI_SUGGESTIONS.engine_trouble;
    else if (lower.includes('battery') || lower.includes('jump')) responses = AI_SUGGESTIONS.battery_dead;

    setAiLoading(false);
    responses.forEach((r, i) => {
      setTimeout(() => setAiMessages(m => [...m, { role: 'ai', text: r }]), i * 700);
    });
  };

  const handleBook = () => {
    if (!selectedMechanic || !selectedIssue) { showToast('Please select issue and mechanic', 'error'); return; }
    if (!vehicleBrand.trim()) { showToast('Please enter your vehicle brand/model', 'error'); return; }
    if (bookingType === 'scheduled' && !scheduledTime) { showToast('Please pick a schedule time', 'error'); return; }

    const id = createBooking({
      mechanicId:      selectedMechanic.id,
      mechanicName:    selectedMechanic.name,
      mechanicAvatar:  selectedMechanic.avatar,
      vehicleType,
      vehicleBrand,
      issueType:       issueData?.label || selectedIssue,
      issueDescription,
      bookingType,
      scheduledTime:   scheduledTime || undefined,
      location:        currentUser?.location || 'Pune',
      coordinates:     { lat: 18.52, lng: 73.86 },
      estimatedAmount: 500,
      mechanicEta:     selectedMechanic.eta,
    });

    setCreatedId(id);
    setBookingDone(true);
    showToast('Booking sent! Mechanic will accept shortly. 🎉', 'success');
  };

  // Success Screen
  if (bookingDone) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[80vh]">
        <div className="max-w-md w-full text-center space-y-6 animate-fade-in-up">
          <div className="text-7xl animate-float">✅</div>
          <h2 className="text-3xl font-black text-white">Booking Confirmed!</h2>
          <p className="text-slate-400">Your request has been sent to {selectedMechanic?.name}. They will accept shortly.</p>
          <div className="dash-card text-left space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Booking ID</span>
              <span className="text-orange-400 font-mono font-bold">#{createdId.slice(-8)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Mechanic</span>
              <span className="text-white font-semibold">{selectedMechanic?.name}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Issue</span>
              <span className="text-white">{issueData?.label}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">ETA</span>
              <span className="text-green-400 font-semibold">{selectedMechanic?.eta} min</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Est. Cost</span>
              <span className="text-white">{issueData?.estimatedCost}</span>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setActiveTab('tracking')} className="btn-primary flex-1 justify-center">
              📍 Track Live
            </button>
            <button onClick={() => { setBookingDone(false); setStep(1); setSelectedIssue(''); setSelectedMechanic(null); }} className="btn-secondary flex-1 justify-center">
              New Booking
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-white">Book a Mechanic</h1>
        <p className="text-slate-400 text-sm mt-1">AI-powered matching • GPS tracking • Instant confirmation</p>
      </div>

      {/* Step Indicators */}
      <div className="flex items-center gap-2">
        {[
          { n: 1, label: 'Issue' },
          { n: 2, label: 'Mechanic' },
          { n: 3, label: 'Details' },
          { n: 4, label: 'Confirm' },
        ].map((s, i) => (
          <React.Fragment key={s.n}>
            <div
              className={`flex items-center gap-2 cursor-pointer ${step >= s.n ? 'opacity-100' : 'opacity-40'}`}
              onClick={() => step > s.n && setStep(s.n as Step)}
            >
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                step > s.n ? 'bg-green-500 text-white' : step === s.n ? 'bg-orange-500 text-white' : 'bg-slate-700 text-slate-400'
              }`}>
                {step > s.n ? '✓' : s.n}
              </div>
              <span className={`text-xs font-medium hidden sm:block ${step === s.n ? 'text-orange-400' : 'text-slate-500'}`}>{s.label}</span>
            </div>
            {i < 3 && <div className={`flex-1 h-0.5 rounded ${step > s.n ? 'bg-green-500' : step === s.n ? 'bg-orange-500/40' : 'bg-slate-700'}`} />}
          </React.Fragment>
        ))}
      </div>

      {/* ─── STEP 1: Select Issue ─── */}
      {step === 1 && (
        <div className="space-y-5">
          {/* AI Assistant */}
          <div className="dash-card">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
                <Bot size={16} className="text-white" />
              </div>
              <div>
                <div className="text-white font-bold text-sm">AI Smart Assistant</div>
                <div className="text-slate-500 text-xs">Describe your problem in any language</div>
              </div>
            </div>
            <div className="h-52 overflow-y-auto space-y-3 mb-3 pr-1">
              {aiMessages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'ai' && (
                    <span className="text-lg mr-2 shrink-0">🤖</span>
                  )}
                  <div className={`max-w-[80%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-orange-500 text-white rounded-tr-sm'
                      : 'bg-slate-800 text-slate-200 rounded-tl-sm border border-slate-700'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {aiLoading && (
                <div className="flex items-center gap-2">
                  <span className="text-lg">🤖</span>
                  <div className="bg-slate-800 border border-slate-700 px-4 py-2.5 rounded-2xl rounded-tl-sm flex items-center gap-2">
                    <Loader size={12} className="animate-spin text-orange-400" />
                    <span className="text-slate-400 text-xs">Analyzing...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
            <div className="flex gap-2">
              <input
                className="input-dark text-sm py-2.5"
                placeholder="Describe your problem... e.g., 'My car won't start'"
                value={aiInput}
                onChange={e => setAiInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendAiMessage()}
              />
              <button onClick={sendAiMessage} disabled={!aiInput.trim()} className="btn-primary px-3 py-2.5 shrink-0">
                <Send size={16} />
              </button>
            </div>
          </div>

          {/* Issue Grid */}
          <div className="dash-card">
            <h3 className="text-white font-bold mb-4">Select Your Issue</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {VEHICLE_ISSUES.map(issue => (
                <button
                  key={issue.id}
                  onClick={() => setSelectedIssue(issue.id)}
                  className={`p-3 rounded-xl border-2 text-left transition-all hover:border-orange-500/50 ${
                    selectedIssue === issue.id
                      ? 'border-orange-500 bg-orange-500/10'
                      : 'border-slate-700 bg-slate-800/50'
                  }`}
                >
                  <div className="text-2xl mb-1.5">{issue.icon}</div>
                  <div className={`text-xs font-semibold mb-1 ${selectedIssue === issue.id ? 'text-orange-300' : 'text-white'}`}>
                    {issue.label}
                  </div>
                  <div className="text-slate-500 text-xs">{issue.estimatedCost}</div>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => { if (!selectedIssue) { showToast('Please select an issue', 'error'); return; } setStep(2); }}
            className="btn-primary w-full justify-center"
          >
            Find Mechanics <ChevronRight size={18} />
          </button>
        </div>
      )}

      {/* ─── STEP 2: Select Mechanic ─── */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-[180px]">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input className="input-dark pl-9 text-sm" placeholder="Search mechanics..." value={searchMech} onChange={e => setSearchMech(e.target.value)} />
            </div>
            <select className="input-dark text-sm w-auto" style={{ width: 'auto', minWidth: 120 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="all">All Status</option>
              <option value="available">Available</option>
              <option value="busy">Busy</option>
            </select>
            <select className="input-dark text-sm w-auto" style={{ width: 'auto', minWidth: 130 }} value={filterRating} onChange={e => setFilterRating(Number(e.target.value))}>
              <option value={0}>Any Rating</option>
              <option value={4}>4+ Stars</option>
              <option value={4.5}>4.5+ Stars</option>
            </select>
          </div>

          {/* Mechanic Cards */}
          <div className="space-y-3">
            {filteredMechanics.map(mech => (
              <div
                key={mech.id}
                onClick={() => setSelectedMechanic(mech)}
                className={`dash-card cursor-pointer transition-all border-2 ${
                  selectedMechanic?.id === mech.id ? 'border-orange-500' : 'border-transparent hover:border-slate-600'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className="text-4xl shrink-0">{mech.avatar}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-white font-bold">{mech.name}</span>
                      {mech.verified && (
                        <span className="text-xs bg-green-500/15 text-green-400 border border-green-500/30 px-1.5 py-0.5 rounded-full">✓ Verified</span>
                      )}
                      <StatusBadge status={mech.status} />
                    </div>
                    <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1.5 text-xs text-slate-400">
                      <span className="flex items-center gap-1"><span className="text-yellow-400">⭐</span> {mech.rating} ({mech.totalReviews} reviews)</span>
                      <span className="flex items-center gap-1"><MapPin size={10} className="text-orange-400" /> {mech.distance} km</span>
                      <span className="flex items-center gap-1"><Clock size={10} className="text-green-400" /> {mech.eta} min ETA</span>
                      <span className="flex items-center gap-1">🛠️ {mech.completedJobs} jobs</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {mech.specialization.slice(0, 4).map(s => (
                        <span key={s} className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded-full">{s}</span>
                      ))}
                    </div>
                    <div className="text-slate-500 text-xs mt-2">{mech.priceRange} • {mech.experience} yrs exp</div>
                  </div>
                  <div className="shrink-0 flex flex-col items-end gap-2">
                    {selectedMechanic?.id === mech.id && (
                      <CheckCircle size={20} className="text-orange-400" />
                    )}
                    <button
                      onClick={e => { e.stopPropagation(); setSelectedMechanic(mech); }}
                      className="flex items-center gap-1 text-xs text-slate-400 hover:text-white"
                    >
                      <Phone size={12} /> {mech.phone}
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {filteredMechanics.length === 0 && (
              <div className="dash-card text-center py-10 text-slate-500">
                <Filter size={32} className="mx-auto mb-2 opacity-30" />
                <p>No mechanics match your filters</p>
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <button onClick={() => setStep(1)} className="btn-secondary flex-1 justify-center">← Back</button>
            <button
              onClick={() => { if (!selectedMechanic) { showToast('Select a mechanic', 'error'); return; } setStep(3); }}
              className="btn-primary flex-1 justify-center"
            >
              Continue <ChevronRight size={18} />
            </button>
          </div>
        </div>
      )}

      {/* ─── STEP 3: Vehicle & Booking Details ─── */}
      {step === 3 && (
        <div className="space-y-4">
          <div className="dash-card space-y-4">
            <h3 className="text-white font-bold">Vehicle Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-slate-400 text-xs mb-1.5 block">Vehicle Type</label>
                <select className="input-dark text-sm" value={vehicleType} onChange={e => setVehicleType(e.target.value)}>
                  <option value="car">🚗 Car</option>
                  <option value="bike">🏍️ Bike</option>
                  <option value="auto">🛺 Auto</option>
                  <option value="truck">🚛 Truck</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 text-xs mb-1.5 block">Brand & Model *</label>
                <input className="input-dark text-sm" placeholder="e.g. Maruti Swift" value={vehicleBrand} onChange={e => setVehicleBrand(e.target.value)} />
              </div>
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1.5 block">Issue Description (optional)</label>
              <textarea
                className="input-dark text-sm resize-none"
                rows={3}
                placeholder="Describe the problem in detail to help the mechanic prepare..."
                value={issueDescription}
                onChange={e => setIssueDescription(e.target.value)}
              />
            </div>
          </div>

          <div className="dash-card space-y-4">
            <h3 className="text-white font-bold">Booking Type</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { type: 'instant' as const,   icon: <Zap size={20} />,      label: 'Instant Booking',   desc: 'Mechanic arrives ASAP' },
                { type: 'scheduled' as const, icon: <Calendar size={20} />, label: 'Schedule for Later', desc: 'Pick date & time' },
              ].map(bt => (
                <button
                  key={bt.type}
                  onClick={() => setBookingType(bt.type)}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                    bookingType === bt.type ? 'border-orange-500 bg-orange-500/10 text-orange-300' : 'border-slate-700 bg-slate-800/50 text-slate-400'
                  }`}
                >
                  {bt.icon}
                  <span className="font-semibold text-sm">{bt.label}</span>
                  <span className="text-xs opacity-70">{bt.desc}</span>
                </button>
              ))}
            </div>
            {bookingType === 'scheduled' && (
              <div>
                <label className="text-slate-400 text-xs mb-1.5 block">Schedule Date & Time</label>
                <input
                  type="datetime-local"
                  className="input-dark text-sm"
                  value={scheduledTime}
                  onChange={e => setScheduledTime(e.target.value)}
                  min={new Date().toISOString().slice(0, 16)}
                />
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <button onClick={() => setStep(2)} className="btn-secondary flex-1 justify-center">← Back</button>
            <button
              onClick={() => { if (!vehicleBrand.trim()) { showToast('Enter vehicle brand', 'error'); return; } setStep(4); }}
              className="btn-primary flex-1 justify-center"
            >
              Review Booking <ChevronRight size={18} />
            </button>
          </div>
        </div>
      )}

      {/* ─── STEP 4: Confirm ─── */}
      {step === 4 && selectedMechanic && (
        <div className="space-y-4">
          {/* Mechanic summary */}
          <div className="dash-card">
            <h3 className="text-white font-bold mb-4">Booking Summary</h3>
            <div className="flex items-center gap-4 p-4 bg-slate-800 rounded-2xl mb-4">
              <div className="text-4xl">{selectedMechanic.avatar}</div>
              <div>
                <div className="text-white font-bold">{selectedMechanic.name}</div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <span>⭐ {selectedMechanic.rating}</span>
                  <span>•</span>
                  <span>{selectedMechanic.distance} km away</span>
                  <span>•</span>
                  <span className="text-green-400">{selectedMechanic.eta} min ETA</span>
                </div>
                <div className="text-slate-500 text-xs mt-0.5">{selectedMechanic.phone}</div>
              </div>
            </div>
            <div className="space-y-2">
              {[
                { label: 'Issue',        value: issueData?.label || selectedIssue },
                { label: 'Vehicle',      value: `${vehicleType === 'car' ? '🚗' : vehicleType === 'bike' ? '🏍️' : '🛺'} ${vehicleBrand}` },
                { label: 'Booking Type', value: bookingType === 'instant' ? '⚡ Instant' : `📅 ${scheduledTime}` },
                { label: 'Location',     value: currentUser?.location || 'Pune' },
                { label: 'Est. Cost',    value: issueData?.estimatedCost || 'TBD' },
              ].map(row => (
                <div key={row.label} className="flex justify-between text-sm py-2 border-b border-slate-800">
                  <span className="text-slate-400">{row.label}</span>
                  <span className="text-white font-medium text-right max-w-[60%]">{row.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Rating preview */}
          <div className="dash-card">
            <div className="flex items-center gap-3">
              <div className="text-2xl">⭐</div>
              <div>
                <div className="text-white font-semibold text-sm">Mechanic Rating</div>
                <StarRating value={selectedMechanic.rating} readonly size={16} />
              </div>
              <div className="ml-auto text-right">
                <div className="text-xs text-slate-400">{selectedMechanic.totalReviews} reviews</div>
                <div className="text-xs text-slate-400">{selectedMechanic.completedJobs} jobs done</div>
              </div>
            </div>
          </div>

          {/* WhatsApp Notification Sim */}
          <div className="dash-card bg-green-500/5 border border-green-500/20">
            <div className="flex items-center gap-2 text-green-400 text-sm font-semibold mb-1">
              📱 WhatsApp Notification
            </div>
            <div className="text-slate-400 text-xs">
              Booking confirmation will be sent to {currentUser?.phone || '+91 9XXXXXXXX'} and {selectedMechanic.phone}
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={() => setStep(3)} className="btn-secondary flex-1 justify-center">← Back</button>
            <button onClick={handleBook} className="btn-primary flex-1 justify-center text-base py-3.5">
              🔧 Confirm Booking
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default BookingPage;
