import React from 'react';
import { CalendarCheck, MapPin, TrendingUp, Wrench, Zap, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import StatusBadge from '../../components/ui/StatusBadge';
import { MECHANICS } from '../../data/mockData';

const UserDashboard: React.FC = () => {
  const { currentUser, bookings, setActiveTab } = useApp();

  const myBookings  = bookings.filter(b => b.userId === currentUser?.id || b.userId === 'user1');
  const completed   = myBookings.filter(b => b.status === 'completed');
  const activeBooking = myBookings.find(b =>
    ['pending', 'accepted', 'travelling', 'arrived', 'in_progress'].includes(b.status)
  );
  const totalSpent = completed.reduce((s, b) => s + b.amount, 0);
  const ratedOnes  = completed.filter(b => b.rating);
  const avgRating  = ratedOnes.length
    ? (ratedOnes.reduce((s, b) => s + (b.rating ?? 0), 0) / ratedOnes.length)
    : 0;

  const nearbyMechanics = MECHANICS.filter(m => m.status === 'available').slice(0, 3);

  const quickStats = [
    { label: 'Total Bookings', value: String(myBookings.length), icon: <CalendarCheck size={20} />, color: 'from-blue-500 to-blue-600',   bg: 'bg-blue-500/10 text-blue-400' },
    { label: 'Completed',      value: String(completed.length),  icon: <CheckCircle size={20} />,  color: 'from-green-500 to-green-600',  bg: 'bg-green-500/10 text-green-400' },
    { label: 'Total Spent',    value: `Rs.${totalSpent}`,        icon: <TrendingUp size={20} />,   color: 'from-orange-500 to-orange-600',bg: 'bg-orange-500/10 text-orange-400' },
    { label: 'Avg Rating',     value: avgRating > 0 ? avgRating.toFixed(1) : 'N/A', icon: <span className="text-sm">⭐</span>, color: 'from-yellow-500 to-yellow-600', bg: 'bg-yellow-500/10 text-yellow-400' },
  ];

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Greeting */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-white">
            Hello, {currentUser?.name?.split(' ')[0]} 👋
          </h1>
          <p className="text-slate-400 mt-0.5 flex items-center gap-1.5 text-sm">
            <MapPin size={14} className="text-orange-400" />
            {currentUser?.location || 'Baner, Pune'}
          </p>
        </div>
        <button onClick={() => setActiveTab('booking')} className="btn-primary">
          <Zap size={16} /> Book a Mechanic
        </button>
      </div>

      {/* Emergency / Active Booking Banner */}
      {!activeBooking ? (
        <div className="rounded-2xl p-5 flex items-center justify-between" style={{ background: 'linear-gradient(135deg,#f97316,#dc2626)' }}>
          <div>
            <div className="text-white font-bold text-lg">🚨 Need Emergency Help?</div>
            <div className="text-orange-100 text-sm mt-0.5">Mechanics available near you right now!</div>
          </div>
          <button onClick={() => setActiveTab('booking')} className="bg-white text-orange-600 font-bold px-5 py-2.5 rounded-xl hover:bg-orange-50 transition-colors shrink-0 text-sm">
            SOS Booking
          </button>
        </div>
      ) : (
        <div className="dash-card border border-blue-500/20 bg-blue-500/5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
              <span className="text-blue-300 font-bold text-sm">Active Booking</span>
            </div>
            <StatusBadge status={activeBooking.status as any} pulse />
          </div>
          <div className="flex items-center gap-4">
            <div className="text-4xl">{activeBooking.mechanicAvatar}</div>
            <div className="flex-1">
              <div className="text-white font-bold">{activeBooking.mechanicName}</div>
              <div className="text-slate-400 text-sm">{activeBooking.issueType}</div>
              <div className="flex items-center gap-1 text-orange-400 text-xs mt-1">
                <Clock size={12} />
                <span>ETA: {activeBooking.mechanicEta} min</span>
              </div>
            </div>
            <button onClick={() => setActiveTab('tracking')} className="btn-primary text-sm">
              Track Live →
            </button>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickStats.map(stat => (
          <div key={stat.label} className="dash-card card-hover">
            <div className={`inline-flex p-2.5 rounded-xl mb-3 ${stat.bg}`}>
              {stat.icon}
            </div>
            <div className="text-2xl font-black text-white">{stat.value}</div>
            <div className="text-slate-400 text-xs mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Nearby Mechanics + Recent Bookings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Nearby Mechanics */}
        <div className="dash-card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white font-bold flex items-center gap-2">
              <MapPin size={16} className="text-orange-400" /> Nearby Mechanics
            </h2>
            <button onClick={() => setActiveTab('booking')} className="text-orange-400 text-xs hover:underline">
              View All →
            </button>
          </div>
          <div className="space-y-3">
            {nearbyMechanics.map(mech => (
              <div key={mech.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors">
                <div className="text-3xl">{mech.avatar}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-semibold text-sm truncate">{mech.name}</div>
                  <div className="text-slate-400 text-xs">{mech.specialization[0]}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-yellow-400 text-xs">⭐ {mech.rating}</span>
                    <span className="text-slate-600 text-xs">•</span>
                    <span className="text-slate-400 text-xs">{mech.distance} km</span>
                    <span className="text-slate-600 text-xs">•</span>
                    <span className="text-green-400 text-xs">{mech.eta} min</span>
                  </div>
                </div>
                <button onClick={() => setActiveTab('booking')} className="btn-primary text-xs py-1.5 px-3 shrink-0">
                  Book
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Bookings */}
        <div className="dash-card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white font-bold flex items-center gap-2">
              <CalendarCheck size={16} className="text-orange-400" /> Recent Bookings
            </h2>
            <button onClick={() => setActiveTab('history')} className="text-orange-400 text-xs hover:underline">
              View All →
            </button>
          </div>
          <div className="space-y-3">
            {myBookings.slice(0, 4).map(booking => (
              <div key={booking.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50">
                <div className="text-2xl">{booking.mechanicAvatar}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-semibold text-sm truncate">{booking.issueType}</div>
                  <div className="text-slate-400 text-xs">{booking.mechanicName} • {booking.vehicleBrand}</div>
                </div>
                <StatusBadge status={booking.status as any} />
              </div>
            ))}
            {myBookings.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                <Wrench size={32} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">No bookings yet</p>
                <button onClick={() => setActiveTab('booking')} className="btn-primary text-sm mt-3">
                  Book Now
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Issue Types Quick Access */}
      <div className="dash-card">
        <h2 className="text-white font-bold mb-4 flex items-center gap-2">
          <AlertCircle size={16} className="text-orange-400" /> Quick Book by Issue
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { icon: '🔴', label: 'Flat Tyre' },
            { icon: '⚙️', label: 'Engine' },
            { icon: '🔋', label: 'Battery' },
            { icon: '🌡️', label: 'Overheating' },
            { icon: '🛑', label: 'Brakes' },
            { icon: '❄️', label: 'AC Repair' },
          ].map(issue => (
            <button
              key={issue.label}
              onClick={() => setActiveTab('booking')}
              className="flex flex-col items-center gap-2 p-3 rounded-xl bg-slate-800/50 hover:bg-orange-500/10 hover:border-orange-500/30 border border-transparent transition-all text-center group"
            >
              <span className="text-2xl group-hover:scale-110 transition-transform">{issue.icon}</span>
              <span className="text-slate-400 group-hover:text-orange-300 text-xs font-medium transition-colors">{issue.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
