import React from 'react';
import { useApp } from '../../context/AppContext';
import StarRating from '../../components/ui/StarRating';
import { REVIEWS, MECHANICS } from '../../data/mockData';

const ReviewsPage: React.FC = () => {
  const { bookings, currentUser } = useApp();
  const myCompleted = bookings.filter(b =>
    (b.userId === currentUser?.id || b.userId === 'user1') &&
    b.status === 'completed' && b.rating
  );

  const allReviews = [...REVIEWS, ...myCompleted.map(b => ({
    id: b.id, bookingId: b.id, userId: b.userId, userName: b.userName,
    userAvatar: b.userAvatar, mechanicId: b.mechanicId,
    rating: b.rating || 0, comment: b.review || '',
    date: b.completedAt || b.createdAt, tags: [] as string[],
  }))];

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-white">Reviews & Ratings</h1>
        <p className="text-slate-400 text-sm mt-1">Your feedback history</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {MECHANICS.slice(0, 3).map(mech => {
          return (
            <div key={mech.id} className="dash-card">
              <div className="flex items-center gap-3 mb-3">
                <div className="text-3xl">{mech.avatar}</div>
                <div>
                  <div className="text-white font-semibold text-sm">{mech.name}</div>
                  <div className="text-slate-400 text-xs">{mech.specialization[0]}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <StarRating value={mech.rating} readonly size={14} />
                <span className="text-yellow-400 font-bold text-sm">{mech.rating}</span>
                <span className="text-slate-500 text-xs">({mech.totalReviews})</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Review List */}
      <div className="space-y-4">
        <h2 className="text-white font-bold">All Reviews</h2>
        {allReviews.map((review, i) => {
          const mech = MECHANICS.find(m => m.id === review.mechanicId);
          return (
            <div key={`${review.id}-${i}`} className="dash-card card-hover">
              <div className="flex items-start gap-4">
                <div className="text-3xl">{review.userAvatar}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <span className="text-white font-semibold">{review.userName}</span>
                      <span className="text-slate-500 text-xs ml-2">→ {mech?.name || 'Mechanic'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <StarRating value={review.rating} readonly size={14} />
                      <span className="text-slate-500 text-xs">{new Date(review.date).toLocaleDateString('en-IN')}</span>
                    </div>
                  </div>
                  {review.comment && (
                    <p className="text-slate-300 text-sm mt-2 leading-relaxed">"{review.comment}"</p>
                  )}
                  {review.tags?.length > 0 && (
                    <div className="flex gap-2 mt-2 flex-wrap">
                      {review.tags.map(tag => (
                        <span key={tag} className="text-xs bg-orange-500/10 text-orange-400 border border-orange-500/20 px-2 py-0.5 rounded-full">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        {allReviews.length === 0 && (
          <div className="dash-card text-center py-12">
            <div className="text-5xl mb-3">⭐</div>
            <div className="text-white font-bold mb-2">No Reviews Yet</div>
            <p className="text-slate-400 text-sm">Complete a booking to leave a review</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReviewsPage;
