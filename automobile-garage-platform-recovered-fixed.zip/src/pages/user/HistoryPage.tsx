import React, { useState } from 'react';
import { Search, Calendar, MapPin, CreditCard } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import StatusBadge from '../../components/ui/StatusBadge';
import StarRating from '../../components/ui/StarRating';

const HistoryPage: React.FC = () => {
  const { bookings, currentUser, cancelBooking, setActiveTab } = useApp();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const myBookings = bookings
    .filter(b => b.userId === currentUser?.id || b.userId === 'user1')
    .filter(b => filter === 'all' || b.status === filter)
    .filter(b => !search || b.issueType.toLowerCase().includes(search.toLowerCase()) || b.mechanicName.toLowerCase().includes(search.toLowerCase()));

  const totalSpent = myBookings.filter(b => b.paymentStatus === 'paid').reduce((s, b) => s + b.amount, 0);

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-white">My Bookings</h1>
        <p className="text-slate-400 text-sm mt-1">{myBookings.length} bookings • Total spent: Rs.{totalSpent}</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input-dark pl-9 text-sm" placeholder="Search bookings..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-2 flex-wrap">
          {['all', 'pending', 'completed', 'cancelled', 'in_progress'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold capitalize transition-all border ${
                filter === f ? 'bg-orange-500 text-white border-orange-500' : 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-600'
              }`}
            >
              {f === 'all' ? 'All' : f.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Bookings List */}
      <div className="space-y-4">
        {myBookings.map(booking => (
          <div key={booking.id} className="dash-card card-hover">
            <div className="flex items-start gap-4">
              <div className="text-4xl shrink-0">{booking.mechanicAvatar}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <div>
                    <div className="text-white font-bold">{booking.issueType}</div>
                    <div className="text-slate-400 text-sm">{booking.mechanicName} • {booking.vehicleBrand}</div>
                  </div>
                  <StatusBadge status={booking.status as any} />
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500 mt-2">
                  <span className="flex items-center gap-1"><Calendar size={11} /> {new Date(booking.createdAt).toLocaleDateString('en-IN')}</span>
                  <span className="flex items-center gap-1"><MapPin size={11} /> {booking.location}</span>
                  {booking.amount > 0 && (
                    <span className="flex items-center gap-1"><CreditCard size={11} /> Rs.{booking.amount} • {booking.paymentMethod?.toUpperCase()}</span>
                  )}
                </div>
                {booking.rating && (
                  <div className="flex items-center gap-2 mt-2">
                    <StarRating value={booking.rating} readonly size={14} />
                    {booking.review && <span className="text-slate-400 text-xs italic">"{booking.review.slice(0, 60)}..."</span>}
                  </div>
                )}
              </div>
            </div>
            <div className="flex gap-2 mt-4 pt-4 border-t border-slate-800">
              {['pending', 'accepted'].includes(booking.status) && (
                <button onClick={() => cancelBooking(booking.id)} className="btn-danger text-xs py-1.5 px-3">
                  Cancel
                </button>
              )}
              {booking.status === 'travelling' && (
                <button onClick={() => setActiveTab('tracking')} className="btn-primary text-xs py-1.5 px-3">
                  Track Live →
                </button>
              )}
              <div className="ml-auto text-right">
                {booking.estimatedAmount > 0 && (
                  <div className="text-slate-500 text-xs">
                    {booking.amount > 0 ? `Final: Rs.${booking.amount}` : `Est: Rs.${booking.estimatedAmount}`}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {myBookings.length === 0 && (
          <div className="dash-card text-center py-16">
            <div className="text-5xl mb-4">📋</div>
            <div className="text-white font-bold text-lg mb-2">No Bookings Found</div>
            <p className="text-slate-400 text-sm mb-4">
              {filter !== 'all' ? 'No bookings with this filter' : "You haven't made any bookings yet"}
            </p>
            <button onClick={() => setActiveTab('booking')} className="btn-primary">Book Now</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryPage;
