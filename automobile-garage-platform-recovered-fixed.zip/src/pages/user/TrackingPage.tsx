import React, { useState, useEffect } from 'react';
import { Phone, MessageSquare, MapPin, Clock, CheckCircle, CreditCard, RefreshCw } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import MapSimulation from '../../components/ui/MapSimulation';
import StatusBadge from '../../components/ui/StatusBadge';
import StarRating from '../../components/ui/StarRating';

const TrackingPage: React.FC = () => {
  const { bookings, currentUser, updateBookingStatus, rateBooking, setActiveTab } = useApp();

  const activeBooking =
    bookings.find(b =>
      (b.userId === currentUser?.id || b.userId === 'user1') &&
      ['pending', 'accepted', 'travelling', 'arrived', 'in_progress', 'completed'].includes(b.status)
    ) || bookings.find(b => b.userId === 'user1');

  const [ratingVal, setRatingVal]       = useState(5);
  const [reviewText, setReviewText]     = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'cash' | 'card'>('upi');
  const [paymentDone, setPaymentDone]   = useState(false);
  const [showRating, setShowRating]     = useState(false);
  const [ratingDone, setRatingDone]     = useState(false);
  const [simStatus, setSimStatus]       = useState(activeBooking?.status || 'pending');
  const [etaCountdown, setEtaCountdown] = useState(activeBooking?.mechanicEta || 15);

  useEffect(() => {
    if (simStatus === 'travelling' && etaCountdown > 0) {
      const t = setInterval(() => setEtaCountdown(p => Math.max(0, p - 1)), 8000);
      return () => clearInterval(t);
    }
  }, [simStatus, etaCountdown]);

  const statusTimeline = [
    { key: 'pending',     label: 'Booking Sent',         icon: '📤' },
    { key: 'accepted',    label: 'Mechanic Accepted',    icon: '✅' },
    { key: 'travelling',  label: 'Mechanic Travelling',  icon: '🚗' },
    { key: 'arrived',     label: 'Mechanic Arrived',     icon: '📍' },
    { key: 'in_progress', label: 'Service in Progress',  icon: '🔧' },
    { key: 'completed',   label: 'Service Completed',    icon: '🎉' },
  ];

  const flow = ['pending', 'accepted', 'travelling', 'arrived', 'in_progress', 'completed'] as const;
  const currentIdx = flow.indexOf(simStatus as typeof flow[number]);

  const handleSimulateNext = () => {
    if (currentIdx < flow.length - 1) {
      const next = flow[currentIdx + 1];
      setSimStatus(next);
      if (activeBooking) updateBookingStatus(activeBooking.id, next);
      if (next === 'completed') { setShowRating(true); }
    }
  };

  const handlePayment = () => {
    setPaymentDone(true);
  };

  const handleRating = () => {
    if (activeBooking) rateBooking(activeBooking.id, ratingVal, reviewText);
    setRatingDone(true);
  };

  if (!activeBooking) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[70vh]">
        <div className="text-center space-y-4">
          <div className="text-6xl">🗺️</div>
          <h2 className="text-2xl font-black text-white">No Active Booking</h2>
          <p className="text-slate-400">You don't have any active bookings to track right now.</p>
          <button onClick={() => setActiveTab('booking')} className="btn-primary">
            Book a Mechanic
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-white">Live Tracking</h1>
          <p className="text-slate-400 text-sm mt-0.5">Booking #{activeBooking.id.slice(-6)}</p>
        </div>
        <StatusBadge status={simStatus as any} pulse />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Map + Controls */}
        <div className="lg:col-span-2 space-y-4">
          {/* Map */}
          <div className="dash-card !p-0 overflow-hidden">
            <MapSimulation
              mechanicName={activeBooking.mechanicName}
              progress={currentIdx * 20}
              eta={etaCountdown}
              status={simStatus}
            />
          </div>

          {/* Mechanic Info Card */}
          <div className="dash-card">
            <div className="flex items-center gap-4">
              <div className="text-5xl">{activeBooking.mechanicAvatar}</div>
              <div className="flex-1">
                <div className="text-white font-bold text-lg">{activeBooking.mechanicName}</div>
                <div className="text-slate-400 text-sm">{activeBooking.issueType}</div>
                <div className="flex items-center gap-3 mt-2">
                  <span className="flex items-center gap-1 text-orange-400 text-sm">
                    <Clock size={14} /> {etaCountdown} min ETA
                  </span>
                  <span className="flex items-center gap-1 text-slate-400 text-sm">
                    <MapPin size={14} /> {activeBooking.location}
                  </span>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <button className="btn-success text-sm py-2 px-3">
                  <Phone size={14} /> Call
                </button>
                <button className="btn-secondary text-sm py-2 px-3">
                  <MessageSquare size={14} /> Chat
                </button>
              </div>
            </div>
          </div>

          {/* Simulate Progress Button */}
          {simStatus !== 'completed' && (
            <button
              onClick={handleSimulateNext}
              className="w-full btn-secondary justify-center border-orange-500/30 text-orange-300 hover:bg-orange-500/10"
            >
              <RefreshCw size={16} /> Simulate Next Step →
            </button>
          )}

          {/* Payment Section */}
          {simStatus === 'completed' && !paymentDone && (
            <div className="dash-card border border-orange-500/20 bg-orange-500/5 space-y-4">
              <h3 className="text-white font-bold flex items-center gap-2">
                <CreditCard size={18} className="text-orange-400" /> Payment
              </h3>
              <div className="flex items-center justify-between text-lg">
                <span className="text-slate-400">Amount Due</span>
                <span className="text-white font-black text-2xl">Rs.{activeBooking.estimatedAmount}</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {(['upi', 'cash', 'card'] as const).map(method => (
                  <button
                    key={method}
                    onClick={() => setPaymentMethod(method)}
                    className={`p-3 rounded-xl border-2 text-sm font-semibold uppercase transition-all ${
                      paymentMethod === method ? 'border-orange-500 bg-orange-500/10 text-orange-300' : 'border-slate-700 text-slate-400'
                    }`}
                  >
                    {method === 'upi' ? '💸 UPI' : method === 'cash' ? '💵 Cash' : '💳 Card'}
                  </button>
                ))}
              </div>
              <button onClick={handlePayment} className="btn-primary w-full justify-center text-base py-3.5">
                Pay Rs.{activeBooking.estimatedAmount} via {paymentMethod.toUpperCase()}
              </button>
            </div>
          )}

          {paymentDone && !ratingDone && (
            <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4 flex items-center gap-3">
              <CheckCircle size={24} className="text-green-400 shrink-0" />
              <div>
                <div className="text-green-300 font-bold">Payment Successful!</div>
                <div className="text-slate-400 text-sm">Rs.{activeBooking.estimatedAmount} paid via {paymentMethod.toUpperCase()}</div>
              </div>
            </div>
          )}

          {ratingDone && (
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-2xl p-4 text-center">
              <div className="text-3xl mb-2">🎉</div>
              <div className="text-yellow-300 font-bold">Thank you for your review!</div>
              <div className="text-slate-400 text-sm mt-1">Your feedback helps other customers.</div>
              <button onClick={() => setActiveTab('dashboard')} className="btn-primary mt-3">
                Back to Dashboard
              </button>
            </div>
          )}
        </div>

        {/* Right: Timeline + Rating */}
        <div className="space-y-4">
          {/* Status Timeline */}
          <div className="dash-card">
            <h3 className="text-white font-bold mb-4">Progress</h3>
            <div className="relative">
              <div className="timeline-line" />
              <div className="space-y-4">
                {statusTimeline.map((s, i) => {
                  const isDone = flow.indexOf(simStatus as typeof flow[number]) >= i;
                  const isCurrent = simStatus === s.key;
                  return (
                    <div key={s.key} className="flex items-start gap-3 pl-1 relative">
                      <div className={`relative z-10 w-8 h-8 rounded-full border-2 flex items-center justify-center text-sm shrink-0 transition-all ${
                        isDone
                          ? 'bg-orange-500 border-orange-500'
                          : 'bg-slate-800 border-slate-700'
                      } ${isCurrent ? 'ring-2 ring-orange-500/40 scale-110' : ''}`}>
                        {isDone ? (isCurrent ? s.icon : '✓') : s.icon}
                      </div>
                      <div className="mt-1">
                        <div className={`text-sm font-semibold ${isDone ? 'text-white' : 'text-slate-500'}`}>{s.label}</div>
                        {isCurrent && (
                          <div className="text-xs text-orange-400 mt-0.5 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-pulse" />
                            In progress...
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Booking Details */}
          <div className="dash-card space-y-2.5">
            <h3 className="text-white font-bold mb-2">Booking Details</h3>
            {[
              { label: 'Vehicle',   value: activeBooking.vehicleBrand },
              { label: 'Issue',     value: activeBooking.issueType },
              { label: 'Location',  value: activeBooking.location },
              { label: 'Type',      value: activeBooking.bookingType === 'instant' ? '⚡ Instant' : '📅 Scheduled' },
              { label: 'Est. Cost', value: `Rs.${activeBooking.estimatedAmount}` },
            ].map(row => (
              <div key={row.label} className="flex justify-between text-sm">
                <span className="text-slate-400">{row.label}</span>
                <span className="text-white font-medium text-right max-w-[60%]">{row.value}</span>
              </div>
            ))}
          </div>

          {/* Rating Panel */}
          {showRating && !ratingDone && (
            <div className="dash-card border border-yellow-500/20 bg-yellow-500/5 space-y-4">
              <h3 className="text-white font-bold">Rate Your Experience</h3>
              <div className="flex justify-center">
                <StarRating value={ratingVal} onChange={v => setRatingVal(v)} size={32} />
              </div>
              <textarea
                className="input-dark text-sm resize-none"
                rows={3}
                placeholder="Write a review (optional)..."
                value={reviewText}
                onChange={e => setReviewText(e.target.value)}
              />
              <button onClick={handleRating} className="btn-primary w-full justify-center">
                Submit Review ⭐
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TrackingPage;
