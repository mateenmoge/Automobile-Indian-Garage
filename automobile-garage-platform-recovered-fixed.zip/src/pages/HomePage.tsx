import React, { useState, useEffect } from 'react';
import { Wrench, MapPin, Star, Clock, ChevronRight, Zap, Shield, BookOpen } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MECHANICS } from '../data/mockData';

const HomePage: React.FC = () => {
  const { setActiveTab, isLoggedIn } = useApp();
  const [counter, setCounter] = useState({ users: 0, mechanics: 0, bookings: 0 });

  useEffect(() => {
    const targets = { users: 2847, mechanics: 156, bookings: 8934 };
    const steps = 60;
    let step = 0;
    const iv = setInterval(() => {
      step++;
      const p = step / steps;
      setCounter({
        users:     Math.round(targets.users * p),
        mechanics: Math.round(targets.mechanics * p),
        bookings:  Math.round(targets.bookings * p),
      });
      if (step >= steps) clearInterval(iv);
    }, 35);
    return () => clearInterval(iv);
  }, []);

  const features = [
    { icon: '🤖', title: 'AI Smart Assistant',    desc: 'Describe your problem in plain language. Our AI matches you with the perfect mechanic instantly.' },
    { icon: '📍', title: 'GPS Live Tracking',      desc: 'Watch your mechanic travel to you in real-time. Accurate ETA updates every minute.' },
    { icon: '⚡', title: 'Instant Booking',        desc: 'Get a mechanic at your doorstep in minutes. Tap and done — no calls needed.' },
    { icon: '📒', title: 'Digital Khata Book',     desc: 'Mechanics track all earnings, dues & payments digitally. Full financial transparency.' },
    { icon: '⭐', title: 'Verified Reviews',       desc: 'Every rating verified through completed bookings. Real reviews from real customers.' },
    { icon: '🔒', title: 'Secure Payments',        desc: 'UPI, Cash, or Card — all transactions are encrypted and receipts auto-generated.' },
  ];

  const workflow = [
    { step: '01', icon: '📱', title: 'Describe Your Issue',    desc: 'Select vehicle type and describe the problem in detail.' },
    { step: '02', icon: '🤖', title: 'AI Finds Best Mechanic', desc: 'Smart algorithm matches nearest verified mechanics for your issue.' },
    { step: '03', icon: '✅', title: 'Mechanic Accepts',       desc: 'Mechanic gets notified instantly and accepts your request.' },
    { step: '04', icon: '🚗', title: 'Track on GPS',           desc: 'Live tracking shows mechanic traveling to your location.' },
    { step: '05', icon: '🔧', title: 'Service Done',           desc: 'Mechanic repairs your vehicle right where you are.' },
    { step: '06', icon: '💳', title: 'Pay & Rate',             desc: 'Pay securely via UPI/Cash. Rate your experience.' },
  ];

  const topMechanics = MECHANICS.filter(m => m.status === 'available').slice(0, 3);

  return (
    <div className="min-h-screen" style={{ background: '#0f172a' }}>
      {/* ── NAVBAR ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-nav">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#f97316,#ea580c)' }}>
              <Wrench size={20} className="text-white" />
            </div>
            <div>
              <span className="text-white font-black text-lg tracking-tight">AutoGarage</span>
              <span className="text-orange-400 font-bold text-lg"> India</span>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-8">
            {['Features', 'How It Works', 'Mechanics', 'About'].map(item => (
              <a key={item} href={`#${item.toLowerCase().replace(' ', '-')}`}
                className="text-slate-300 hover:text-orange-400 text-sm font-medium transition-colors">
                {item}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-3">
            {isLoggedIn ? (
              <button onClick={() => setActiveTab('dashboard')} className="btn-primary py-2 px-5 text-sm">
                Dashboard →
              </button>
            ) : (
              <>
                <button onClick={() => setActiveTab(isLoggedIn ? 'dashboard' : 'auth')} className="btn-secondary text-sm">
                  Login
                </button>
                <button onClick={() => setActiveTab(isLoggedIn ? 'dashboard' : 'auth')} className="btn-primary text-sm">
                  Get Started
                </button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className="hero-bg pt-28 pb-20 px-6 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 right-10 text-[120px] opacity-5 animate-float">🔧</div>
          <div className="absolute bottom-10 left-10 text-[100px] opacity-5 animate-float" style={{ animationDelay: '1s' }}>🚗</div>
          <div className="absolute top-1/3 left-1/3 text-[80px] opacity-5 animate-float" style={{ animationDelay: '2s' }}>⚙️</div>
          {/* Glowing orbs */}
          <div className="absolute top-20 left-1/4 w-72 h-72 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #f97316, transparent)' }} />
          <div className="absolute bottom-20 right-1/4 w-72 h-72 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #3b82f6, transparent)' }} />
        </div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-400 text-sm font-semibold mb-6 animate-fade-in-up">
            <span className="w-2 h-2 rounded-full bg-orange-400 animate-pulse" />
            🇮🇳 Made for India's Roads
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-white mb-6 animate-fade-in-up leading-tight" style={{ animationDelay: '0.1s' }}>
            Your Trusted <br />
            <span className="gradient-text">Roadside Mechanic</span><br />
            is One Tap Away
          </h1>
          <p className="text-xl text-slate-400 mb-10 max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            AI-powered platform connecting you with verified local mechanics. GPS tracking, instant booking, and digital payments — all in one place.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            <button onClick={() => setActiveTab(isLoggedIn ? 'dashboard' : 'auth')} className="btn-primary text-lg px-8 py-4">
              🚗 Book a Mechanic Now
            </button>
            <button onClick={() => setActiveTab(isLoggedIn ? 'dashboard' : 'auth')}
              className="btn-secondary text-base px-8 py-4 border-orange-500/30 text-orange-300">
              🔧 Register as Mechanic
            </button>
          </div>
          {/* Trust pills */}
          <div className="flex flex-wrap gap-4 justify-center mt-10 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            {['✅ Verified Mechanics', '⚡ Avg. 12 min response', '⭐ 4.8/5 rating', '📍 GPS Tracking'].map(pill => (
              <div key={pill} className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-slate-300 text-sm font-medium">
                {pill}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <section className="py-16 px-6" style={{ background: '#0f172a' }}>
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { value: counter.users.toLocaleString(), label: 'Happy Customers', icon: '👥', color: 'from-blue-500 to-blue-600' },
              { value: counter.mechanics.toString(),   label: 'Verified Mechanics', icon: '🔧', color: 'from-orange-500 to-orange-600' },
              { value: counter.bookings.toLocaleString(), label: 'Successful Bookings', icon: '✅', color: 'from-green-500 to-green-600' },
            ].map(stat => (
              <div key={stat.label} className="dash-card flex items-center gap-5 card-hover">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-2xl shrink-0 shadow-lg`}>
                  {stat.icon}
                </div>
                <div>
                  <div className="text-3xl font-black text-white">{stat.value}+</div>
                  <div className="text-slate-400 text-sm mt-0.5">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" className="py-20 px-6" style={{ background: '#0f172a' }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl font-black text-white mb-4">
              Everything You Need, <span className="gradient-text">Right Here</span>
            </h2>
            <p className="text-slate-400 text-lg max-w-xl mx-auto">
              A complete ecosystem for vehicle emergencies and maintenance
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map(f => (
              <div key={f.title} className="dash-card card-hover group">
                <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">{f.icon}</div>
                <h3 className="text-white font-bold text-lg mb-2">{f.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section id="how-it-works" className="py-20 px-6" style={{ background: '#1e293b' }}>
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl font-black text-white mb-4">
              How It <span className="gradient-text">Works</span>
            </h2>
            <p className="text-slate-400 text-lg">From problem to solution in 6 simple steps</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {workflow.map((w, i) => (
              <div key={w.step} className="relative dash-card card-hover" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="text-orange-500/20 font-black text-6xl absolute top-3 right-4 leading-none">{w.step}</div>
                <div className="text-4xl mb-3 relative">{w.icon}</div>
                <h3 className="text-white font-bold mb-2 relative">{w.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed relative">{w.desc}</p>
                {i < workflow.length - 1 && (
                  <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10">
                    <ChevronRight className="text-orange-500" size={24} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TOP MECHANICS ── */}
      <section id="mechanics" className="py-20 px-6" style={{ background: '#0f172a' }}>
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl font-black text-white mb-4">
              Our Top <span className="gradient-text">Mechanics</span>
            </h2>
            <p className="text-slate-400 text-lg">Verified professionals ready to help you</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {topMechanics.map(mech => (
              <div key={mech.id} className="dash-card card-hover">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center text-3xl">
                      {mech.avatar}
                    </div>
                    <div>
                      <div className="text-white font-bold">{mech.name}</div>
                      <div className="flex items-center gap-1.5 text-sm text-slate-400">
                        <MapPin size={12} />
                        <span>{mech.location.address}</span>
                      </div>
                    </div>
                  </div>
                  {mech.verified && (
                    <span className="text-xs bg-green-500/15 text-green-400 border border-green-500/30 px-2 py-0.5 rounded-full font-semibold">
                      ✓ Verified
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex items-center gap-1">
                    <Star size={14} className="text-yellow-400 fill-yellow-400" />
                    <span className="text-yellow-400 font-bold text-sm">{mech.rating}</span>
                    <span className="text-slate-500 text-xs">({mech.totalReviews})</span>
                  </div>
                  <span className="text-slate-600">•</span>
                  <div className="flex items-center gap-1 text-slate-400 text-sm">
                    <Clock size={12} />
                    <span>{mech.eta} min ETA</span>
                  </div>
                  <span className="text-slate-600">•</span>
                  <div className="flex items-center gap-1 text-slate-400 text-sm">
                    <MapPin size={12} />
                    <span>{mech.distance} km</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {mech.specialization.slice(0, 3).map(s => (
                    <span key={s} className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded-full">
                      {s}
                    </span>
                  ))}
                </div>
                <div className="text-sm text-slate-400 mb-4">{mech.priceRange}</div>
                <button
                  onClick={() => setActiveTab(isLoggedIn ? 'dashboard' : 'auth')}
                  className="w-full btn-primary justify-center text-sm py-2.5"
                >
                  Book Now →
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 px-6" style={{ background: '#1e293b' }}>
        <div className="max-w-4xl mx-auto">
          <div className="rounded-3xl p-12 text-center relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #f97316, #ea580c, #dc2626)' }}>
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute top-4 right-8 text-6xl opacity-20 animate-float">🔧</div>
              <div className="absolute bottom-4 left-8 text-5xl opacity-20 animate-float" style={{ animationDelay: '1s' }}>🚗</div>
            </div>
            <div className="relative z-10">
              <h2 className="text-4xl font-black text-white mb-4">Stuck on the Road?</h2>
              <p className="text-orange-100 text-xl mb-8">
                Don't panic. Tap once and get a verified mechanic at your doorstep in minutes.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => setActiveTab(isLoggedIn ? 'dashboard' : 'auth')}
                  className="bg-white text-orange-600 font-black px-10 py-4 rounded-2xl text-lg hover:bg-orange-50 transition-colors shadow-xl"
                >
                  🚨 Emergency Booking
                </button>
                <button
                  onClick={() => setActiveTab(isLoggedIn ? 'dashboard' : 'auth')}
                  className="bg-white/15 border border-white/30 text-white font-bold px-10 py-4 rounded-2xl text-lg hover:bg-white/20 transition-colors"
                >
                  📅 Schedule Service
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" className="py-20 px-6" style={{ background: '#0f172a' }}>
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-400 text-xs font-semibold mb-5">
                🛠️ Our Mission
              </div>
              <h2 className="text-4xl font-black text-white mb-6">
                Empowering Local <span className="gradient-text">Mechanics</span>
              </h2>
              <p className="text-slate-400 text-lg leading-relaxed mb-6">
                Automobile Indian Garage is a social impact platform designed to connect local mechanics from small towns and rural areas with customers who need them most.
              </p>
              <p className="text-slate-400 leading-relaxed mb-8">
                We provide a digital bridge where mechanics can grow their business, manage earnings digitally, and build a trusted reputation — while customers get fast, reliable roadside assistance.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: <Shield size={18} />, text: 'Verified Mechanics' },
                  { icon: <Zap size={18} />,    text: 'Instant Booking' },
                  { icon: <MapPin size={18} />, text: 'GPS Tracking' },
                  { icon: <BookOpen size={18} />, text: 'Digital Khata' },
                ].map(item => (
                  <div key={item.text} className="flex items-center gap-2 text-slate-300 text-sm">
                    <span className="text-orange-400">{item.icon}</span>
                    {item.text}
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { emoji: '🏆', title: 'Project Lead',    value: 'Mateen Moge' },
                { emoji: '📍', title: 'Based in',        value: 'India' },
                { emoji: '🎓', title: 'Project Type',    value: 'Final Year' },
                { emoji: '🚀', title: 'Platform',        value: 'Web + Mobile' },
              ].map(card => (
                <div key={card.title} className="dash-card text-center">
                  <div className="text-3xl mb-2">{card.emoji}</div>
                  <div className="text-slate-400 text-xs mb-1">{card.title}</div>
                  <div className="text-white font-bold text-sm">{card.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="py-8 px-6 border-t border-slate-800">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#f97316,#ea580c)' }}>
              <Wrench size={16} className="text-white" />
            </div>
            <span className="text-white font-bold">Automobile Indian Garage</span>
          </div>
          <div className="text-slate-500 text-sm">
            Built with ❤️ by <span className="text-orange-400 font-semibold">Mateen Moge</span> — Final Year Engineering Project
          </div>
          <div className="flex items-center gap-4">
            {['Privacy', 'Terms', 'Contact'].map(item => (
              <a key={item} href="#" className="text-slate-500 hover:text-orange-400 text-sm transition-colors">{item}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
