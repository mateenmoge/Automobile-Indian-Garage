import React, { useState } from 'react';
import { User, Phone, Mail, MapPin, Edit2, Save, Camera, Shield, Star } from 'lucide-react';
import { useApp } from '../context/AppContext';

const ProfilePage: React.FC = () => {
  const { currentUser, bookings, showToast, logout } = useApp();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    name:     currentUser?.name || '',
    phone:    currentUser?.phone || '',
    location: currentUser?.location || '',
  });

  const myBookings  = bookings.filter(b => b.userId === currentUser?.id || b.userId === 'user1');
  const completed   = myBookings.filter(b => b.status === 'completed');
  const _totalSpent  = completed.reduce((s, b) => s + b.amount, 0); void _totalSpent;
  const ratedOnes   = completed.filter(b => b.rating);
  const avgRating   = ratedOnes.length
    ? (ratedOnes.reduce((s, b) => s + (b.rating ?? 0), 0) / ratedOnes.length).toFixed(1)
    : 'N/A';

  const handleSave = () => {
    showToast('Profile updated successfully! ✅', 'success');
    setEditing(false);
  };

  const roleConfig = {
    user:     { label: 'Customer',     color: 'from-blue-500 to-blue-600',    icon: '👤', badge: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
    mechanic: { label: 'Mechanic',     color: 'from-orange-500 to-orange-600', icon: '🔧', badge: 'text-orange-400 bg-orange-500/10 border-orange-500/30' },
    admin:    { label: 'Administrator', color: 'from-purple-500 to-purple-600', icon: '🛡️', badge: 'text-purple-400 bg-purple-500/10 border-purple-500/30' },
  }[currentUser?.role || 'user'];

  return (
    <div className="p-6 space-y-6 animate-fade-in max-w-3xl">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black text-white">My Profile</h1>
        <button onClick={editing ? handleSave : () => setEditing(true)} className={editing ? 'btn-primary' : 'btn-secondary'}>
          {editing ? <><Save size={16} /> Save Changes</> : <><Edit2 size={16} /> Edit Profile</>}
        </button>
      </div>

      {/* Profile Card */}
      <div className="dash-card">
        <div className="flex items-start gap-6 flex-wrap">
          {/* Avatar */}
          <div className="relative">
            <div className={`w-24 h-24 rounded-3xl bg-gradient-to-br ${roleConfig.color} flex items-center justify-center text-5xl shadow-xl`}>
              {currentUser?.avatar}
            </div>
            <button className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center shadow-lg hover:bg-orange-600 transition-colors">
              <Camera size={14} className="text-white" />
            </button>
          </div>
          {/* Info */}
          <div className="flex-1 min-w-[200px]">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-2xl font-black text-white">{currentUser?.name}</h2>
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${roleConfig.badge}`}>
                {roleConfig.icon} {roleConfig.label}
              </span>
            </div>
            <div className="space-y-1.5 text-sm text-slate-400">
              <div className="flex items-center gap-2"><Mail size={14} className="text-orange-400" /> {currentUser?.email}</div>
              <div className="flex items-center gap-2"><Phone size={14} className="text-orange-400" /> {currentUser?.phone}</div>
              <div className="flex items-center gap-2"><MapPin size={14} className="text-orange-400" /> {currentUser?.location}</div>
            </div>
          </div>
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Bookings', value: String(myBookings.length), icon: '📋' },
              { label: 'Completed', value: String(completed.length), icon: '✅' },
              { label: 'Avg Rating', value: avgRating, icon: '⭐' },
            ].map(s => (
              <div key={s.label} className="text-center p-3 bg-slate-800 rounded-xl">
                <div className="text-xl mb-1">{s.icon}</div>
                <div className="text-white font-black text-lg">{s.value}</div>
                <div className="text-slate-500 text-xs">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Edit Form */}
      {editing && (
        <div className="dash-card space-y-4 animate-fade-in">
          <h3 className="text-white font-bold">Edit Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 text-xs mb-1.5 block flex items-center gap-1"><User size={12} /> Full Name</label>
              <input className="input-dark text-sm" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div>
              <label className="text-slate-400 text-xs mb-1.5 block flex items-center gap-1"><Phone size={12} /> Phone</label>
              <input className="input-dark text-sm" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            </div>
            <div className="sm:col-span-2">
              <label className="text-slate-400 text-xs mb-1.5 block flex items-center gap-1"><MapPin size={12} /> Location</label>
              <input className="input-dark text-sm" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} />
            </div>
          </div>
        </div>
      )}

      {/* Security */}
      <div className="dash-card space-y-4">
        <h3 className="text-white font-bold flex items-center gap-2"><Shield size={16} className="text-orange-400" /> Security</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button className="btn-secondary justify-center">🔑 Change Password</button>
          <button className="btn-secondary justify-center">📱 Verify Phone</button>
        </div>
      </div>

      {/* Vehicles (for users) */}
      {currentUser?.role === 'user' && (
        <div className="dash-card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-bold">My Vehicles</h3>
            <button className="btn-primary text-xs py-1.5 px-3">+ Add Vehicle</button>
          </div>
          <div className="space-y-3">
            {[
              { type: '🚗', brand: 'Maruti Suzuki Swift', reg: 'MH-12-AB-1234', color: 'White', year: 2021 },
              { type: '🏍️', brand: 'Honda Activa 6G',    reg: 'MH-12-CD-5678', color: 'Blue',  year: 2022 },
            ].map(v => (
              <div key={v.reg} className="flex items-center gap-3 p-3 bg-slate-800 rounded-xl">
                <div className="text-3xl">{v.type}</div>
                <div className="flex-1">
                  <div className="text-white font-semibold text-sm">{v.brand}</div>
                  <div className="text-slate-400 text-xs">{v.reg} • {v.color} • {v.year}</div>
                </div>
                <button className="text-slate-500 hover:text-orange-400 transition-colors">
                  <Edit2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Earnings summary (for mechanics) */}
      {currentUser?.role === 'mechanic' && (
        <div className="dash-card">
          <h3 className="text-white font-bold mb-4 flex items-center gap-2"><Star size={16} className="text-orange-400" /> Professional Info</h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Experience', value: '12 years' },
              { label: 'Specialization', value: 'Engine, Electrical' },
              { label: 'Languages', value: 'Hindi, Marathi' },
              { label: 'Joined', value: 'March 2022' },
            ].map(item => (
              <div key={item.label} className="bg-slate-800 p-3 rounded-xl">
                <div className="text-slate-400 text-xs">{item.label}</div>
                <div className="text-white font-semibold text-sm mt-0.5">{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Danger Zone */}
      <div className="dash-card border border-red-500/20">
        <h3 className="text-red-400 font-bold mb-3">Danger Zone</h3>
        <div className="flex gap-3">
          <button onClick={logout} className="btn-danger text-sm">🚪 Logout</button>
          <button className="bg-red-500/10 text-red-400 border border-red-500/30 font-semibold px-4 py-2 rounded-xl text-sm hover:bg-red-500/15 transition-colors">
            🗑️ Delete Account
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
