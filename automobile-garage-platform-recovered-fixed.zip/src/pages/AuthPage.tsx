import React, { useState } from 'react';
import { Wrench, Mail, Lock, User, Phone, Eye, EyeOff, Loader } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { UserRole } from '../data/mockData';

interface Props {
  defaultMode?: 'login' | 'signup';
}

const AuthPage: React.FC<Props> = ({ defaultMode = 'login' }) => {
  const { login, signup, showToast } = useApp();

  const [mode, setMode] = useState<'login' | 'signup'>(defaultMode);
  const [role, setRole] = useState<'user' | 'mechanic'>('user');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    name: '', email: '', phone: '', password: '', confirmPassword: ''
  });

  const set = (field: string, val: string) => setForm(f => ({ ...f, [field]: val }));

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email || !form.password) { showToast('Please fill all fields', 'error'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const ok = await login(form.email, form.password);
    setLoading(false);
    if (!ok) showToast('Invalid credentials. Try demo accounts below.', 'error');
    else showToast('Welcome back! 🎉', 'success');
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone || !form.password) {
      showToast('Please fill all fields', 'error'); return;
    }
    if (form.password !== form.confirmPassword) {
      showToast('Passwords do not match', 'error'); return;
    }
    if (form.password.length < 6) {
      showToast('Password must be at least 6 characters', 'error'); return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    await signup(form.name, form.email, form.phone, form.password, role as UserRole);
    setLoading(false);
    showToast('Account created successfully! 🎉', 'success');
  };

  const fillDemo = (type: 'user' | 'mechanic' | 'admin') => {
    const creds = {
      user: { email: 'user@demo.com', password: 'demo123' },
      mechanic: { email: 'mechanic@demo.com', password: 'demo123' },
      admin: { email: 'admin@demo.com', password: 'admin123' },
    }[type];
    setForm(f => ({ ...f, ...creds }));
    showToast(`Demo ${type} credentials filled!`, 'info');
  };

  return (
    <div className="min-h-screen hero-bg flex items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 text-8xl opacity-5 animate-float">🔧</div>
        <div className="absolute bottom-20 right-10 text-8xl opacity-5 animate-float" style={{ animationDelay: '1s' }}>🚗</div>
        <div className="absolute top-1/2 left-1/4 text-6xl opacity-5 animate-float" style={{ animationDelay: '2s' }}>⚙️</div>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8 animate-fade-in-up">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl mb-4"
            style={{ background: 'linear-gradient(135deg, #f97316, #ea580c)' }}>
            <Wrench size={40} className="text-white" />
          </div>
          <h1 className="text-3xl font-black text-white">Automobile</h1>
          <p className="text-orange-400 font-semibold text-lg">Indian Garage</p>
          <p className="text-slate-400 text-sm mt-1">Your trusted roadside mechanic</p>
        </div>

        {/* Card */}
        <div className="glass rounded-3xl p-8 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
          {/* Tabs */}
          <div className="flex bg-slate-800 rounded-2xl p-1 mb-6">
            {(['login', 'signup'] as const).map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 py-2.5 rounded-xl font-semibold text-sm capitalize transition-all duration-200 ${
                  mode === m
                    ? 'bg-orange-500 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {m === 'login' ? 'Login' : 'Sign Up'}
              </button>
            ))}
          </div>

          {/* Role selector (signup only) */}
          {mode === 'signup' && (
            <div className="flex gap-3 mb-5">
              {(['user', 'mechanic'] as const).map(r => (
                <button
                  key={r}
                  onClick={() => setRole(r)}
                  className={`flex-1 py-3 rounded-xl border-2 font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                    role === r
                      ? 'border-orange-500 bg-orange-500/10 text-orange-400'
                      : 'border-slate-700 text-slate-400 hover:border-slate-500'
                  }`}
                >
                  {r === 'user' ? '👤' : '👨‍🔧'}
                  {r === 'user' ? 'Customer' : 'Mechanic'}
                </button>
              ))}
            </div>
          )}

          {/* Form */}
          <form onSubmit={mode === 'login' ? handleLogin : handleSignup} className="space-y-4">
            {mode === 'signup' && (
              <div className="relative">
                <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Full Name"
                  value={form.name}
                  onChange={e => set('name', e.target.value)}
                  className="form-input pl-10 bg-slate-800 border-slate-700 text-white placeholder-slate-400 focus:border-orange-500"
                />
              </div>
            )}

            <div className="relative">
              <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                placeholder="Email Address"
                value={form.email}
                onChange={e => set('email', e.target.value)}
                className="form-input pl-10 bg-slate-800 border-slate-700 text-white placeholder-slate-400 focus:border-orange-500"
              />
            </div>

            {mode === 'signup' && (
              <div className="relative">
                <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={form.phone}
                  onChange={e => set('phone', e.target.value)}
                  className="form-input pl-10 bg-slate-800 border-slate-700 text-white placeholder-slate-400 focus:border-orange-500"
                />
              </div>
            )}

            <div className="relative">
              <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type={showPass ? 'text' : 'password'}
                placeholder="Password"
                value={form.password}
                onChange={e => set('password', e.target.value)}
                className="form-input pl-10 pr-10 bg-slate-800 border-slate-700 text-white placeholder-slate-400 focus:border-orange-500"
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            {mode === 'signup' && (
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  placeholder="Confirm Password"
                  value={form.confirmPassword}
                  onChange={e => set('confirmPassword', e.target.value)}
                  className="form-input pl-10 bg-slate-800 border-slate-700 text-white placeholder-slate-400 focus:border-orange-500"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary flex items-center justify-center gap-2 py-3.5 mt-2 disabled:opacity-60"
            >
              {loading ? (
                <><Loader size={18} className="animate-spin" /> Please wait...</>
              ) : (
                mode === 'login' ? '🔐 Login' : '🚀 Create Account'
              )}
            </button>
          </form>

          {/* Demo credentials */}
          {mode === 'login' && (
            <div className="mt-6 p-4 bg-slate-800/50 rounded-2xl">
              <p className="text-slate-400 text-xs font-semibold mb-3 uppercase tracking-wide">
                Quick Demo Login
              </p>
              <div className="grid grid-cols-3 gap-2">
                {(['user', 'mechanic', 'admin'] as const).map(t => (
                  <button
                    key={t}
                    onClick={() => fillDemo(t)}
                    className="py-2 px-2 bg-slate-700 hover:bg-slate-600 text-white text-xs rounded-xl font-medium transition-all capitalize"
                  >
                    {t === 'user' ? '👤' : t === 'mechanic' ? '🔧' : '🛡️'} {t}
                  </button>
                ))}
              </div>
              <p className="text-slate-500 text-xs mt-2 text-center">
                Click a role → then Login
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <p className="text-center text-slate-500 text-xs mt-6">
          Project by <span className="text-orange-400 font-semibold">Mateen Moge</span> • Automobile Indian Garage
        </p>
      </div>
    </div>
  );
};

export default AuthPage;
