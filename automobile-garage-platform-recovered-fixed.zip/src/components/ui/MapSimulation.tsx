import React, { useEffect, useState } from 'react';

interface Props {
  mechanicName: string;
  progress?: number;
  eta?: number;
  status?: string;
  compact?: boolean;
}

const MapSimulation: React.FC<Props> = ({
  mechanicName,
  progress = 0,
  eta = 15,
  status = 'travelling',
  compact = false,
}) => {
  const [animProgress, setAnimProgress] = useState(progress);
  const userPos  = { x: 78, y: 32 };
  const startPos = { x: 12, y: 65 };

  const mechX = startPos.x + (userPos.x - startPos.x) * (animProgress / 100);
  const mechY = startPos.y + (userPos.y - startPos.y) * (animProgress / 100);
  const remainingEta = Math.max(0, Math.round(eta * (1 - animProgress / 100)));

  useEffect(() => {
    if (status !== 'travelling') return;
    const iv = setInterval(() => {
      setAnimProgress(p => {
        const next = Math.min(p + 1.2, 96);
        return next;
      });
    }, 500);
    return () => clearInterval(iv);
  }, [status]);

  const height = compact ? 'h-44' : 'h-72';

  return (
    <div className={`map-container ${height} w-full relative overflow-hidden select-none rounded-2xl`}>
      {/* Roads horizontal */}
      {[28, 55, 78].map((top, i) => (
        <div key={i} className="map-road-h" style={{ top: `${top}%` }} />
      ))}
      {/* Roads vertical */}
      {[22, 50, 75].map((left, i) => (
        <div key={i} className="map-road-v" style={{ left: `${left}%` }} />
      ))}

      {/* City blocks */}
      {[
        { x: '4%',  y: '5%',  w: '15%', h: '20%', green: true },
        { x: '27%', y: '4%',  w: '20%', h: '22%', green: false },
        { x: '54%', y: '6%',  w: '17%', h: '19%', green: true },
        { x: '4%',  y: '35%', w: '14%', h: '16%', green: false },
        { x: '27%', y: '35%', w: '20%', h: '16%', green: true },
        { x: '79%', y: '40%', w: '16%', h: '18%', green: false },
        { x: '4%',  y: '62%', w: '14%', h: '22%', green: true },
        { x: '27%', y: '62%', w: '19%', h: '22%', green: false },
        { x: '54%', y: '62%', w: '17%', h: '20%', green: true },
      ].map((b, i) => (
        <div key={i} className="absolute rounded" style={{
          left: b.x, top: b.y, width: b.w, height: b.h,
          background: b.green ? 'rgba(134,239,172,0.3)' : 'rgba(148,163,184,0.22)',
        }} />
      ))}

      {/* Dashed path */}
      <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: 'none' }}>
        <defs>
          <marker id="arrow" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto">
            <path d="M0,0 L8,4 L0,8 Z" fill="#f97316" />
          </marker>
        </defs>
        <line
          x1={`${startPos.x}%`} y1={`${startPos.y}%`}
          x2={`${userPos.x}%`}  y2={`${userPos.y}%`}
          stroke="#f97316" strokeWidth="2"
          strokeDasharray="6,4" opacity="0.5"
        />
        {/* Progress line */}
        <line
          x1={`${startPos.x}%`} y1={`${startPos.y}%`}
          x2={`${mechX}%`}       y2={`${mechY}%`}
          stroke="#f97316" strokeWidth="3" opacity="0.85"
          markerEnd="url(#arrow)"
        />
      </svg>

      {/* User location pin */}
      <div className="absolute" style={{ left: `${userPos.x}%`, top: `${userPos.y}%`, transform: 'translate(-50%,-100%)' }}>
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-blue-500 border-3 border-white flex items-center justify-center shadow-lg map-ping">
            <span className="text-sm">🏠</span>
          </div>
        </div>
        <div className="bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full mt-1 whitespace-nowrap font-semibold shadow">
          You
        </div>
      </div>

      {/* Mechanic marker */}
      {status === 'travelling' || status === 'accepted' ? (
        <div className="absolute transition-all duration-500" style={{ left: `${mechX}%`, top: `${mechY}%`, transform: 'translate(-50%,-100%)' }}>
          <div className="relative pulse-ring">
            <div className="w-9 h-9 rounded-full bg-orange-500 border-2 border-white flex items-center justify-center shadow-xl">
              <span className="text-base">🔧</span>
            </div>
          </div>
          <div className="bg-orange-600 text-white text-xs px-2 py-0.5 rounded-full mt-1 whitespace-nowrap font-semibold shadow text-center">
            {mechanicName.split(' ')[0]}
          </div>
        </div>
      ) : (
        <div className="absolute" style={{ left: `${startPos.x}%`, top: `${startPos.y}%`, transform: 'translate(-50%,-100%)' }}>
          <div className="w-8 h-8 rounded-full bg-slate-500 border-2 border-white flex items-center justify-center shadow">
            <span className="text-sm">🔧</span>
          </div>
        </div>
      )}

      {/* ETA Badge */}
      {!compact && (
        <div className="absolute top-3 left-3 bg-slate-900/90 text-white px-3 py-2 rounded-xl text-sm font-bold shadow-xl border border-slate-700">
          <div className="text-orange-400 text-xs font-normal">ETA</div>
          <div>{remainingEta} min</div>
        </div>
      )}

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-slate-900/40">
        <div
          className="h-full bg-gradient-to-r from-orange-400 to-orange-600 transition-all duration-500"
          style={{ width: `${animProgress}%` }}
        />
      </div>

      {/* Status overlay for arrived/completed */}
      {(status === 'arrived' || status === 'in_progress' || status === 'completed') && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-slate-900/95 border border-slate-700 rounded-2xl px-6 py-4 text-center shadow-2xl">
            <div className="text-3xl mb-2">
              {status === 'arrived' ? '📍' : status === 'in_progress' ? '🔧' : '✅'}
            </div>
            <div className="text-white font-bold">
              {status === 'arrived' ? 'Mechanic Arrived!' : status === 'in_progress' ? 'Service in Progress' : 'Service Completed!'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MapSimulation;
