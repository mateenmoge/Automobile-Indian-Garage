import React from 'react';

type Status =
  | 'pending' | 'accepted' | 'travelling' | 'arrived'
  | 'in_progress' | 'completed' | 'cancelled'
  | 'available' | 'busy' | 'offline'
  | 'paid' | 'failed';

const CONFIG: Record<Status, { label: string; color: string; dot: string }> = {
  pending:     { label: 'Pending',      color: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',  dot: 'bg-yellow-400' },
  accepted:    { label: 'Accepted',     color: 'bg-blue-500/15 text-blue-400 border-blue-500/30',        dot: 'bg-blue-400' },
  travelling:  { label: 'On the Way',   color: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30',  dot: 'bg-indigo-400' },
  arrived:     { label: 'Arrived',      color: 'bg-purple-500/15 text-purple-400 border-purple-500/30',  dot: 'bg-purple-400' },
  in_progress: { label: 'In Progress',  color: 'bg-orange-500/15 text-orange-400 border-orange-500/30', dot: 'bg-orange-400' },
  completed:   { label: 'Completed',    color: 'bg-green-500/15 text-green-400 border-green-500/30',     dot: 'bg-green-400' },
  cancelled:   { label: 'Cancelled',    color: 'bg-red-500/15 text-red-400 border-red-500/30',           dot: 'bg-red-400' },
  available:   { label: 'Available',    color: 'bg-green-500/15 text-green-400 border-green-500/30',     dot: 'bg-green-400' },
  busy:        { label: 'Busy',         color: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',  dot: 'bg-yellow-400' },
  offline:     { label: 'Offline',      color: 'bg-slate-500/15 text-slate-400 border-slate-500/30',     dot: 'bg-slate-400' },
  paid:        { label: 'Paid',         color: 'bg-green-500/15 text-green-400 border-green-500/30',     dot: 'bg-green-400' },
  failed:      { label: 'Failed',       color: 'bg-red-500/15 text-red-400 border-red-500/30',           dot: 'bg-red-400' },
};

interface Props { status: Status; pulse?: boolean; }

const StatusBadge: React.FC<Props> = ({ status, pulse }) => {
  const cfg = CONFIG[status] ?? CONFIG.pending;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${cfg.color}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot} ${pulse ? 'animate-pulse' : ''}`} />
      {cfg.label}
    </span>
  );
};

export default StatusBadge;
