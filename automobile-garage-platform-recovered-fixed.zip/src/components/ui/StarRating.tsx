import React from 'react';

interface Props {
  value: number;
  onChange?: (v: number) => void;
  size?: number;
  readonly?: boolean;
}

const StarRating: React.FC<Props> = ({ value, onChange, size = 20, readonly = false }) => {
  const [hover, setHover] = React.useState(0);
  const display = readonly ? value : (hover || value);

  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(star => (
        <span
          key={star}
          style={{ fontSize: size, cursor: readonly ? 'default' : 'pointer', lineHeight: 1 }}
          className={`transition-transform ${!readonly && hover >= star ? 'scale-110' : ''}`}
          onClick={() => !readonly && onChange?.(star)}
          onMouseEnter={() => !readonly && setHover(star)}
          onMouseLeave={() => !readonly && setHover(0)}
        >
          {display >= star ? '⭐' : '☆'}
        </span>
      ))}
    </div>
  );
};

export default StarRating;
