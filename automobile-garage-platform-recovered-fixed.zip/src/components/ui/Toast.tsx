import React from 'react';
import { CheckCircle, XCircle, Info, X } from 'lucide-react';

interface Props {
  message: string;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}

const Toast: React.FC<Props> = ({ message, type, onClose }) => {
  const config = {
    success: { icon: <CheckCircle size={18} />, bg: 'bg-green-500', border: 'border-green-400' },
    error:   { icon: <XCircle size={18} />,     bg: 'bg-red-500',   border: 'border-red-400' },
    info:    { icon: <Info size={18} />,         bg: 'bg-blue-500',  border: 'border-blue-400' },
  }[type];

  return (
    <div className={`fixed bottom-6 right-6 z-[9999] flex items-center gap-3 px-5 py-3.5 rounded-2xl text-white shadow-2xl border ${config.bg} ${config.border} animate-slide-right`}>
      {config.icon}
      <span className="text-sm font-medium max-w-xs">{message}</span>
      <button onClick={onClose} className="ml-2 opacity-75 hover:opacity-100 transition-opacity">
        <X size={16} />
      </button>
    </div>
  );
};

export default Toast;
