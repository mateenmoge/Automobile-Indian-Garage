import React, { useState } from 'react';
import {
  LayoutDashboard, CalendarCheck, MapPin, Star, BookOpen,
  User, Settings, LogOut, Wrench, Bell, ChevronLeft, ChevronRight,
  Shield, TrendingUp, Users, MessageSquare
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

const Sidebar: React.FC = () => {
  const { currentUser, activeTab, setActiveTab, logout, notifications } = useApp();
  const [collapsed, setCollapsed] = useState(false);

  const unread = notifications.filter(n => !n.read && n.userId === currentUser?.id).length;

  const userNavItems: { id: string; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
    { id: 'booking', label: 'Book Mechanic', icon: <CalendarCheck size={18} /> },
    { id: 'tracking', label: 'Live Tracking', icon: <MapPin size={18} /> },
    { id: 'history', label: 'My Bookings', icon: <BookOpen size={18} /> },
    { id: 'reviews', label: 'Reviews', icon: <Star size={18} /> },
    { id: 'profile', label: 'My Profile', icon: <User size={18} /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell size={18} />, badge: unread },
  ];

  const mechanicNavItems: { id: string; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
    { id: 'requests', label: 'Job Requests', icon: <CalendarCheck size={18} /> },
    { id: 'tracking', label: 'Navigation', icon: <MapPin size={18} /> },
    { id: 'khata', label: 'Digital Khata', icon: <BookOpen size={18} /> },
    { id: 'history', label: 'Job History', icon: <TrendingUp size={18} /> },
    { id: 'reviews', label: 'My Reviews', icon: <Star size={18} /> },
    { id: 'profile', label: 'My Profile', icon: <User size={18} /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell size={18} />, badge: unread },
  ];

  const adminNavItems: { id: string; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
    { id: 'users', label: 'Users', icon: <Users size={18} /> },
    { id: 'mechanics', label: 'Mechanics', icon: <Wrench size={18} /> },
    { id: 'bookings-admin', label: 'All Bookings', icon: <CalendarCheck size={18} /> },
    { id: 'analytics', label: 'Analytics', icon: <TrendingUp size={18} /> },
    { id: 'reports', label: 'Reports', icon: <MessageSquare size={18} /> },
    { id: 'settings', label: 'Settings', icon: <Settings size={18} /> },
  ];

  const navItems = currentUser?.role === 'admin'
    ? adminNavItems
    : currentUser?.role === 'mechanic'
      ? mechanicNavItems
      : userNavItems;

  const roleColors: Record<string, string> = {
    user: 'from-blue-500 to-blue-600',
    mechanic: 'from-orange-500 to-orange-600',
    admin: 'from-purple-500 to-purple-600',
  };

  return (
    <aside
      className={`flex flex-col bg-slate-900 border-r border-slate-800 transition-all duration-300 shrink-0 ${
        collapsed ? 'w-16' : 'w-64'
      }`}
      style={{ minHeight: '100vh' }}
    >
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center gap-3">
        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${roleColors[currentUser?.role || 'user']} flex items-center justify-center shrink-0`}>
          {currentUser?.role === 'admin' ? <Shield size={18} className="text-white" /> : <Wrench size={18} className="text-white" />}
        </div>
        {!collapsed && (
          <div className="flex-1 min-w-0">
            <div className="text-white font-bold text-sm truncate">AutoGarage</div>
            <div className="text-slate-400 text-xs capitalize">{currentUser?.role} Portal</div>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-slate-400 hover:text-white ml-auto"
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>

      {/* User Info */}
      {!collapsed && (
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="text-3xl">{currentUser?.avatar}</div>
            <div className="min-w-0">
              <div className="text-white font-semibold text-sm truncate">{currentUser?.name}</div>
              <div className="text-slate-400 text-xs truncate">{currentUser?.email}</div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`sidebar-item w-full ${activeTab === item.id ? 'active' : ''} ${collapsed ? 'justify-center' : ''}`}
            title={collapsed ? item.label : undefined}
          >
            <span className="shrink-0">{item.icon}</span>
            {!collapsed && (
              <>
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge ? (
                  <span className="bg-orange-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                    {item.badge}
                  </span>
                ) : null}
              </>
            )}
          </button>
        ))}
      </nav>

      {/* Home + Logout */}
      <div className="p-3 border-t border-slate-800 space-y-1">
        <button
          onClick={() => setActiveTab('home')}
          className={`sidebar-item w-full ${collapsed ? 'justify-center' : ''}`}
          title={collapsed ? 'Home' : undefined}
        >
          <Wrench size={18} />
          {!collapsed && <span>Home Page</span>}
        </button>
        <button
          onClick={logout}
          className={`sidebar-item w-full text-red-400 hover:bg-red-500/10 hover:text-red-400 ${collapsed ? 'justify-center' : ''}`}
          title={collapsed ? 'Logout' : undefined}
        >
          <LogOut size={18} />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
