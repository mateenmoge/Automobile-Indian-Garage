// ============================================================
// MOCK DATA – Automobile Indian Garage
// ============================================================

export type UserRole = 'user' | 'mechanic' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar: string;
  location: { lat: number; lng: number; address: string };
  createdAt: string;
  vehicles?: Vehicle[];
}

export interface Vehicle {
  id: string;
  type: 'bike' | 'car' | 'truck' | 'auto';
  brand: string;
  model: string;
  year: number;
  regNumber: string;
  color: string;
}

export interface Mechanic {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar: string;
  specialization: string[];
  experience: number; // years
  rating: number;
  totalReviews: number;
  location: { lat: number; lng: number; address: string };
  distance: number; // km
  eta: number; // minutes
  status: 'available' | 'busy' | 'offline';
  verified: boolean;
  priceRange: string;
  completedJobs: number;
  joinedDate: string;
  languages: string[];
  bio: string;
  khataBalance: number;
}

export interface Booking {
  id: string;
  userId: string;
  mechanicId: string;
  mechanicName: string;
  userName: string;
  vehicleType: string;
  vehicleBrand: string;
  issueType: string;
  issueDescription: string;
  status: 'pending' | 'accepted' | 'travelling' | 'arrived' | 'in_progress' | 'completed' | 'cancelled';
  bookingType: 'instant' | 'scheduled';
  scheduledTime?: string;
  location: string;
  coordinates: { lat: number; lng: number };
  amount: number;
  estimatedAmount: number;
  paymentStatus: 'pending' | 'paid' | 'failed';
  paymentMethod?: 'upi' | 'cash' | 'card';
  rating?: number;
  review?: string;
  createdAt: string;
  completedAt?: string;
  mechanicEta: number;
  mechanicAvatar: string;
  userAvatar: string;
}

export interface Review {
  id: string;
  bookingId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  mechanicId: string;
  rating: number;
  comment: string;
  date: string;
  tags: string[];
}

export interface KhataEntry {
  id: string;
  mechanicId: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  customerName: string;
  date: string;
  bookingId?: string;
  paid: boolean;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'booking' | 'payment' | 'system' | 'alert';
  read: boolean;
  createdAt: string;
}

// ============================================================
// SEED DATA
// ============================================================

export const MECHANICS: Mechanic[] = [
  {
    id: 'mech1',
    name: 'Ramesh Kumar',
    email: 'ramesh@garage.com',
    phone: '+91 98765 43210',
    avatar: '👨‍🔧',
    specialization: ['Engine Repair', 'Oil Change', 'Brakes', 'Electrical'],
    experience: 12,
    rating: 4.8,
    totalReviews: 234,
    location: { lat: 18.52, lng: 73.86, address: 'Shivajinagar, Pune' },
    distance: 1.2,
    eta: 8,
    status: 'available',
    verified: true,
    priceRange: 'Rs.200 - Rs.2000',
    completedJobs: 892,
    joinedDate: '2022-03-15',
    languages: ['Hindi', 'Marathi', 'English'],
    bio: 'Expert mechanic with 12 years of experience. Specializing in all types of vehicles. Quick and reliable service at your doorstep.',
    khataBalance: 15420,
  },
  {
    id: 'mech2',
    name: 'Suresh Patil',
    email: 'suresh@garage.com',
    phone: '+91 87654 32109',
    avatar: '🧑‍🔧',
    specialization: ['Tyre Change', 'Puncture Repair', 'AC Service', 'Suspension'],
    experience: 8,
    rating: 4.6,
    totalReviews: 156,
    location: { lat: 18.51, lng: 73.88, address: 'Kothrud, Pune' },
    distance: 2.1,
    eta: 14,
    status: 'available',
    verified: true,
    priceRange: '₹150 – ₹1500',
    completedJobs: 567,
    joinedDate: '2022-08-20',
    languages: ['Marathi', 'Hindi'],
    bio: 'Trusted mechanic in Kothrud area. Known for puncture and tyre services. Available 24x7 for emergencies.',
    khataBalance: 8750,
  },
  {
    id: 'mech3',
    name: 'Ganesh Salve',
    email: 'ganesh@garage.com',
    phone: '+91 76543 21098',
    avatar: '👷',
    specialization: ['Battery Service', 'Starting Problems', 'Wiring', 'Alternator'],
    experience: 15,
    rating: 4.9,
    totalReviews: 389,
    location: { lat: 18.53, lng: 73.85, address: 'Deccan, Pune' },
    distance: 3.4,
    eta: 20,
    status: 'busy',
    verified: true,
    priceRange: '₹300 – ₹3000',
    completedJobs: 1240,
    joinedDate: '2021-01-10',
    languages: ['Marathi', 'Hindi', 'English'],
    bio: 'Senior mechanic with 15+ years. Electrical system expert. Certified from ITI Pune. Handles all two-wheelers and four-wheelers.',
    khataBalance: 24300,
  },
  {
    id: 'mech4',
    name: 'Vikram Singh',
    email: 'vikram@garage.com',
    phone: '+91 65432 10987',
    avatar: '👨‍🏭',
    specialization: ['Denting', 'Painting', 'Body Work', 'Windshield'],
    experience: 6,
    rating: 4.4,
    totalReviews: 98,
    location: { lat: 18.50, lng: 73.87, address: 'Hadapsar, Pune' },
    distance: 4.8,
    eta: 28,
    status: 'available',
    verified: false,
    priceRange: '₹500 – ₹10000',
    completedJobs: 312,
    joinedDate: '2023-05-12',
    languages: ['Hindi', 'Punjabi'],
    bio: 'Specialist in body work, denting and painting. Quality work at reasonable prices. Based in Hadapsar.',
    khataBalance: 4200,
  },
  {
    id: 'mech5',
    name: 'Pradeep Yadav',
    email: 'pradeep@garage.com',
    phone: '+91 54321 09876',
    avatar: '🔧',
    specialization: ['Two-Wheeler', 'Bike Repair', 'Chain', 'Carburetor'],
    experience: 10,
    rating: 4.7,
    totalReviews: 201,
    location: { lat: 18.54, lng: 73.89, address: 'Aundh, Pune' },
    distance: 5.2,
    eta: 32,
    status: 'available',
    verified: true,
    priceRange: '₹100 – ₹1000',
    completedJobs: 743,
    joinedDate: '2022-11-08',
    languages: ['Hindi', 'Bhojpuri'],
    bio: 'Two-wheeler specialist. Fast, affordable and reliable. Available for all bike brands including Hero, Honda, Bajaj, TVS.',
    khataBalance: 11800,
  },
];

export const VEHICLE_ISSUES = [
  { id: 'flat_tyre', label: 'Flat Tyre / Puncture', icon: '🔴', category: 'Tyre', estimatedCost: '₹100 – ₹500' },
  { id: 'engine_trouble', label: 'Engine Not Starting', icon: '⚙️', category: 'Engine', estimatedCost: '₹300 – ₹2000' },
  { id: 'battery_dead', label: 'Battery Dead / Jump Start', icon: '🔋', category: 'Electrical', estimatedCost: '₹200 – ₹1500' },
  { id: 'overheating', label: 'Engine Overheating', icon: '🌡️', category: 'Engine', estimatedCost: '₹500 – ₹3000' },
  { id: 'brake_fail', label: 'Brake Failure / Soft Brakes', icon: '🛑', category: 'Brakes', estimatedCost: '₹400 – ₹2500' },
  { id: 'oil_change', label: 'Oil Change / Leak', icon: '🛢️', category: 'Maintenance', estimatedCost: '₹200 – ₹800' },
  { id: 'ac_not_working', label: 'AC Not Working', icon: '❄️', category: 'AC', estimatedCost: '₹500 – ₹3000' },
  { id: 'clutch', label: 'Clutch Problem', icon: '🔩', category: 'Transmission', estimatedCost: '₹300 – ₹2000' },
  { id: 'electrical', label: 'Electrical / Wiring Issue', icon: '⚡', category: 'Electrical', estimatedCost: '₹300 – ₹2000' },
  { id: 'suspension', label: 'Suspension / Noise', icon: '🔊', category: 'Suspension', estimatedCost: '₹500 – ₹4000' },
  { id: 'denting', label: 'Denting & Painting', icon: '🎨', category: 'Body', estimatedCost: '₹1000 – ₹15000' },
  { id: 'general', label: 'General Service', icon: '🔧', category: 'Maintenance', estimatedCost: '₹500 – ₹2000' },
];

export const BOOKINGS: Booking[] = [
  {
    id: 'book1',
    userId: 'user1',
    mechanicId: 'mech1',
    mechanicName: 'Ramesh Kumar',
    userName: 'Arjun Sharma',
    vehicleType: 'car',
    vehicleBrand: 'Maruti Suzuki Swift',
    issueType: 'Battery Dead / Jump Start',
    issueDescription: "Car won't start. Battery seems completely dead.",
    status: 'completed',
    bookingType: 'instant',
    location: 'Shivajinagar, Pune',
    coordinates: { lat: 18.52, lng: 73.86 },
    amount: 450,
    estimatedAmount: 400,
    paymentStatus: 'paid',
    paymentMethod: 'upi',
    rating: 5,
    review: 'Ramesh came very quickly and fixed my car in 20 minutes. Excellent service!',
    createdAt: '2024-12-10T10:30:00',
    completedAt: '2024-12-10T11:15:00',
    mechanicEta: 8,
    mechanicAvatar: '👨‍🔧',
    userAvatar: '👤',
  },
  {
    id: 'book2',
    userId: 'user1',
    mechanicId: 'mech2',
    mechanicName: 'Suresh Patil',
    userName: 'Arjun Sharma',
    vehicleType: 'bike',
    vehicleBrand: 'Honda Activa',
    issueType: 'Flat Tyre / Puncture',
    issueDescription: 'Front tyre puncture on highway.',
    status: 'completed',
    bookingType: 'instant',
    location: 'Kothrud, Pune',
    coordinates: { lat: 18.51, lng: 73.88 },
    amount: 180,
    estimatedAmount: 150,
    paymentStatus: 'paid',
    paymentMethod: 'cash',
    rating: 4,
    review: 'Good service. Fixed puncture quickly.',
    createdAt: '2024-12-05T14:20:00',
    completedAt: '2024-12-05T14:55:00',
    mechanicEta: 14,
    mechanicAvatar: '🧑‍🔧',
    userAvatar: '👤',
  },
  {
    id: 'book3',
    userId: 'user1',
    mechanicId: 'mech1',
    mechanicName: 'Ramesh Kumar',
    userName: 'Arjun Sharma',
    vehicleType: 'car',
    vehicleBrand: 'Hyundai i20',
    issueType: 'Oil Change / Leak',
    issueDescription: 'Scheduled oil change for 10,000 km service.',
    status: 'in_progress',
    bookingType: 'scheduled',
    scheduledTime: '2025-01-15T09:00:00',
    location: 'Home – Baner, Pune',
    coordinates: { lat: 18.56, lng: 73.78 },
    amount: 0,
    estimatedAmount: 650,
    paymentStatus: 'pending',
    createdAt: '2025-01-10T18:00:00',
    mechanicEta: 0,
    mechanicAvatar: '👨‍🔧',
    userAvatar: '👤',
  },
];

export const REVIEWS: Review[] = [
  {
    id: 'rev1',
    bookingId: 'book1',
    userId: 'user1',
    userName: 'Arjun Sharma',
    userAvatar: '👤',
    mechanicId: 'mech1',
    rating: 5,
    comment: 'Ramesh came very quickly and fixed my car in 20 minutes. Very professional and charged fairly. Highly recommend!',
    date: '2024-12-10',
    tags: ['Quick Response', 'Affordable', 'Professional'],
  },
  {
    id: 'rev2',
    bookingId: 'book2',
    userId: 'user2',
    userName: 'Priya Desai',
    userAvatar: '👩',
    mechanicId: 'mech1',
    rating: 5,
    comment: 'Amazing service! Had engine trouble at midnight and Ramesh came within 10 minutes. Real lifesaver!',
    date: '2024-11-28',
    tags: ['24x7 Available', 'Trustworthy'],
  },
  {
    id: 'rev3',
    bookingId: 'book3',
    userId: 'user3',
    userName: 'Rohit Verma',
    userAvatar: '👨',
    mechanicId: 'mech2',
    rating: 4,
    comment: 'Suresh fixed my puncture in under 10 minutes. Good value for money.',
    date: '2024-11-20',
    tags: ['Fast', 'Affordable'],
  },
];

export const KHATA_ENTRIES: KhataEntry[] = [
  {
    id: 'k1',
    mechanicId: 'mech1',
    type: 'credit',
    amount: 450,
    description: 'Battery jump start – Swift',
    customerName: 'Arjun Sharma',
    date: '2024-12-10',
    bookingId: 'book1',
    paid: true,
  },
  {
    id: 'k2',
    mechanicId: 'mech1',
    type: 'credit',
    amount: 800,
    description: 'Engine service – Alto',
    customerName: 'Sneha Joshi',
    date: '2024-12-09',
    paid: true,
  },
  {
    id: 'k3',
    mechanicId: 'mech1',
    type: 'debit',
    amount: 1200,
    description: 'Spare parts purchase – AutoMart',
    customerName: 'AutoMart Store',
    date: '2024-12-08',
    paid: true,
  },
  {
    id: 'k4',
    mechanicId: 'mech1',
    type: 'credit',
    amount: 350,
    description: 'Tyre puncture x2 – WagonR',
    customerName: 'Raj Mehta',
    date: '2024-12-08',
    paid: false,
  },
  {
    id: 'k5',
    mechanicId: 'mech1',
    type: 'credit',
    amount: 1500,
    description: 'Full service – Honda City',
    customerName: 'Vikram Bose',
    date: '2024-12-07',
    paid: true,
  },
  {
    id: 'k6',
    mechanicId: 'mech1',
    type: 'debit',
    amount: 500,
    description: 'Monthly tool maintenance',
    customerName: 'Tool Shop',
    date: '2024-12-01',
    paid: true,
  },
];

export const AI_SUGGESTIONS: Record<string, string[]> = {
  flat_tyre: [
    'I recommend Suresh Patil (⭐ 4.6) – Tyre specialist, only 2.1 km away, ETA 14 mins.',
    'Pradeep Yadav (⭐ 4.7) is also available for two-wheelers, 5.2 km away.',
    'Estimated cost: ₹100–₹500. Suresh has completed 200+ tyre repairs.',
  ],
  engine_trouble: [
    'Ramesh Kumar (⭐ 4.8) is our top pick – Engine expert, 1.2 km away, ETA 8 mins!',
    'Ganesh Salve (⭐ 4.9) specializes in electrical/engine issues, but currently busy.',
    'Estimated cost: ₹300–₹2000. Describe your symptoms for a precise quote.',
  ],
  battery_dead: [
    'Ganesh Salve (⭐ 4.9) – Electrical & battery expert, 3.4 km, ETA 20 mins.',
    'Ramesh Kumar (⭐ 4.8) also handles battery issues, 1.2 km, ETA 8 mins.',
    'For jump start only: ₹200–₹400. Battery replacement: ₹1000–₹4000.',
  ],
  default: [
    'Based on your location, Ramesh Kumar (⭐ 4.8) is the nearest verified mechanic.',
    'Please describe your issue in detail so I can find the best specialist.',
    'Multiple mechanics are available in your area. Average ETA is 15 mins.',
  ],
};

export const DEMO_USERS = {
  user: { email: 'user@demo.com', password: 'demo123', role: 'user' as UserRole },
  mechanic: { email: 'mechanic@demo.com', password: 'demo123', role: 'mechanic' as UserRole },
  admin: { email: 'admin@demo.com', password: 'admin123', role: 'admin' as UserRole },
};

export const NOTIFICATION_TEMPLATES = {
  bookingReceived: (name: string) => `New booking request from ${name}! Check your dashboard.`,
  mechanicAccepted: (name: string) => `${name} has accepted your request and is on the way! 🚗`,
  mechanicArrived: () => 'Mechanic has arrived at your location!',
  paymentSuccess: (amount: number) => `Payment of ₹${amount} received successfully. Thank you!`,
  bookingCompleted: () => 'Service completed! Please rate your experience.',
};

export const MONTHLY_EARNINGS = [
  { month: 'Jul', earnings: 12400, jobs: 34 },
  { month: 'Aug', earnings: 15200, jobs: 42 },
  { month: 'Sep', earnings: 11800, jobs: 31 },
  { month: 'Oct', earnings: 18600, jobs: 51 },
  { month: 'Nov', earnings: 16200, jobs: 45 },
  { month: 'Dec', earnings: 21400, jobs: 58 },
];

export const ADMIN_STATS = {
  totalUsers: 2847,
  totalMechanics: 156,
  totalBookings: 8934,
  totalRevenue: 4256800,
  activeBookings: 23,
  avgRating: 4.6,
  citiesCovered: 12,
  successRate: 96.4,
};
