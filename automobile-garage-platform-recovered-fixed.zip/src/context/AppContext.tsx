import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { UserRole, Booking, Mechanic, KhataEntry, Notification } from '../data/mockData';
import {
  BOOKINGS, MECHANICS, KHATA_ENTRIES,
  DEMO_USERS, NOTIFICATION_TEMPLATES
} from '../data/mockData';

// ──────────────────────────────────────────
// Types
// ──────────────────────────────────────────
export interface AuthUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar: string;
  location: string;
  mechanicId?: string;
}

interface AppState {
  // Auth
  currentUser: AuthUser | null;
  isLoggedIn: boolean;
  // Data
  bookings: Booking[];
  mechanics: Mechanic[];
  khataEntries: KhataEntry[];
  notifications: Notification[];
  // UI
  activeTab: string;
  toastMessage: string | null;
  toastType: 'success' | 'error' | 'info';
  // Booking flow
  currentBooking: Partial<Booking> | null;
  bookingStep: number;
  // GPS simulation
  mechanicPosition: { lat: number; lng: number; progress: number } | null;
}

interface AppContextValue extends AppState {
  // Auth actions
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, phone: string, password: string, role: UserRole) => Promise<boolean>;
  logout: () => void;
  // Booking actions
  createBooking: (booking: Partial<Booking>) => string;
  updateBookingStatus: (bookingId: string, status: Booking['status']) => void;
  cancelBooking: (bookingId: string) => void;
  rateBooking: (bookingId: string, rating: number, review: string) => void;
  // Mechanic actions
  updateMechanicStatus: (mechanicId: string, status: Mechanic['status']) => void;
  acceptBooking: (bookingId: string) => void;
  // UI actions
  setActiveTab: (tab: string) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  setCurrentBooking: (booking: Partial<Booking> | null) => void;
  setBookingStep: (step: number) => void;
  markNotificationRead: (id: string) => void;
  addKhataEntry: (entry: Omit<KhataEntry, 'id'>) => void;
}

// ──────────────────────────────────────────
// Context
// ──────────────────────────────────────────
const AppContext = createContext<AppContextValue | null>(null);

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};

// ──────────────────────────────────────────
// Provider
// ──────────────────────────────────────────
export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>({
    currentUser: null,
    isLoggedIn: false,
    bookings: BOOKINGS,
    mechanics: MECHANICS,
    khataEntries: KHATA_ENTRIES,
    notifications: [],
    activeTab: 'dashboard',
    toastMessage: null,
    toastType: 'success',
    currentBooking: null,
    bookingStep: 1,
    mechanicPosition: null,
  });

  // Auto-hide toast
  useEffect(() => {
    if (state.toastMessage) {
      const t = setTimeout(() => setState(s => ({ ...s, toastMessage: null })), 3500);
      return () => clearTimeout(t);
    }
  }, [state.toastMessage]);

  // Simulate GPS tracking when booking is in_progress
  useEffect(() => {
    const activeBooking = state.bookings.find(
      b => b.userId === state.currentUser?.id && b.status === 'travelling'
    );
    if (activeBooking && !state.mechanicPosition) {
      setState(s => ({ ...s, mechanicPosition: { lat: 18.52, lng: 73.86, progress: 0 } }));
      let progress = 0;
      const interval = setInterval(() => {
        progress += 2;
        setState(s => ({
          ...s,
          mechanicPosition: { lat: 18.52 + progress * 0.001, lng: 73.86 + progress * 0.001, progress },
        }));
        if (progress >= 100) clearInterval(interval);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [state.bookings, state.currentUser]);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setState(s => ({ ...s, toastMessage: message, toastType: type }));
  }, []);

  const addNotification = useCallback((userId: string, title: string, message: string, type: Notification['type']) => {
    const notif: Notification = {
      id: `n${Date.now()}`,
      userId,
      title,
      message,
      type,
      read: false,
      createdAt: new Date().toISOString(),
    };
    setState(s => ({ ...s, notifications: [notif, ...s.notifications] }));
  }, []);

  // ── AUTH ──────────────────────────────────
  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    const demoEntry = Object.values(DEMO_USERS).find(
      u => u.email === email && u.password === password
    );
    if (!demoEntry) return false;

    let user: AuthUser;
    if (demoEntry.role === 'mechanic') {
      user = {
        id: 'mech1',
        name: 'Ramesh Kumar',
        email: demoEntry.email,
        phone: '+91 98765 43210',
        role: 'mechanic',
        avatar: '👨‍🔧',
        location: 'Shivajinagar, Pune',
        mechanicId: 'mech1',
      };
    } else if (demoEntry.role === 'admin') {
      user = {
        id: 'admin1',
        name: 'Admin User',
        email: demoEntry.email,
        phone: '+91 00000 00000',
        role: 'admin',
        avatar: '🛡️',
        location: 'Mumbai HQ',
      };
    } else {
      user = {
        id: 'user1',
        name: 'Arjun Sharma',
        email: demoEntry.email,
        phone: '+91 91234 56789',
        role: 'user',
        avatar: '👤',
        location: 'Baner, Pune',
      };
    }

    setState(s => ({
      ...s,
      currentUser: user,
      isLoggedIn: true,
      activeTab: 'dashboard',
      notifications: [
        {
          id: 'n0',
          userId: user.id,
          title: 'Welcome back!',
          message: `Hello ${user.name}, welcome to Automobile Indian Garage.`,
          type: 'system',
          read: false,
          createdAt: new Date().toISOString(),
        },
      ],
    }));
    return true;
  }, []);

  const signup = useCallback(async (
    name: string, email: string, phone: string, _password: string, role: UserRole
  ): Promise<boolean> => {
    const user: AuthUser = {
      id: `u${Date.now()}`,
      name, email, phone, role,
      avatar: role === 'mechanic' ? '👨‍🔧' : '👤',
      location: 'India',
      mechanicId: role === 'mechanic' ? `mech${Date.now()}` : undefined,
    };
    setState(s => ({
      ...s,
      currentUser: user,
      isLoggedIn: true,
      activeTab: 'dashboard',
      notifications: [{
        id: 'nw1',
        userId: user.id,
        title: 'Account Created!',
        message: `Welcome ${name}! Your account has been created successfully.`,
        type: 'system',
        read: false,
        createdAt: new Date().toISOString(),
      }],
    }));
    return true;
  }, []);

  const logout = useCallback(() => {
    setState(s => ({
      ...s,
      currentUser: null,
      isLoggedIn: false,
      activeTab: 'dashboard',
      currentBooking: null,
      bookingStep: 1,
      mechanicPosition: null,
    }));
  }, []);

  // ── BOOKINGS ──────────────────────────────
  const createBooking = useCallback((partial: Partial<Booking>): string => {
    const id = `book${Date.now()}`;
    const booking: Booking = {
      id,
      userId: state.currentUser?.id || 'user1',
      mechanicId: partial.mechanicId || 'mech1',
      mechanicName: partial.mechanicName || 'Ramesh Kumar',
      userName: state.currentUser?.name || 'User',
      vehicleType: partial.vehicleType || 'car',
      vehicleBrand: partial.vehicleBrand || 'Unknown',
      issueType: partial.issueType || 'General',
      issueDescription: partial.issueDescription || '',
      status: 'pending',
      bookingType: partial.bookingType || 'instant',
      scheduledTime: partial.scheduledTime,
      location: partial.location || state.currentUser?.location || 'Pune',
      coordinates: partial.coordinates || { lat: 18.52, lng: 73.86 },
      amount: 0,
      estimatedAmount: partial.estimatedAmount || 500,
      paymentStatus: 'pending',
      createdAt: new Date().toISOString(),
      mechanicEta: partial.mechanicEta || 15,
      mechanicAvatar: partial.mechanicAvatar || '👨‍🔧',
      userAvatar: '👤',
    };

    setState(s => ({
      ...s,
      bookings: [booking, ...s.bookings],
    }));

    // Simulate mechanic accepting after 3 seconds
    setTimeout(() => {
      setState(s => ({
        ...s,
        bookings: s.bookings.map(b => b.id === id ? { ...b, status: 'accepted' } : b),
      }));
      addNotification(
        state.currentUser?.id || 'user1',
        'Mechanic Accepted!',
        NOTIFICATION_TEMPLATES.mechanicAccepted(booking.mechanicName),
        'booking'
      );
    }, 3000);

    return id;
  }, [state.currentUser, addNotification]);

  const updateBookingStatus = useCallback((bookingId: string, status: Booking['status']) => {
    setState(s => ({
      ...s,
      bookings: s.bookings.map(b =>
        b.id === bookingId
          ? { ...b, status, completedAt: status === 'completed' ? new Date().toISOString() : b.completedAt }
          : b
      ),
    }));
  }, []);

  const cancelBooking = useCallback((bookingId: string) => {
    setState(s => ({
      ...s,
      bookings: s.bookings.map(b => b.id === bookingId ? { ...b, status: 'cancelled' } : b),
    }));
    showToast('Booking cancelled successfully', 'info');
  }, [showToast]);

  const rateBooking = useCallback((bookingId: string, rating: number, review: string) => {
    setState(s => ({
      ...s,
      bookings: s.bookings.map(b =>
        b.id === bookingId ? { ...b, rating, review, paymentStatus: 'paid' } : b
      ),
    }));
    showToast('Thank you for your review! ⭐', 'success');
  }, [showToast]);

  const acceptBooking = useCallback((bookingId: string) => {
    setState(s => ({
      ...s,
      bookings: s.bookings.map(b =>
        b.id === bookingId ? { ...b, status: 'accepted' } : b
      ),
    }));
    showToast('Booking accepted! Customer has been notified.', 'success');

    // Simulate travelling after 2s
    setTimeout(() => {
      setState(s => ({
        ...s,
        bookings: s.bookings.map(b => b.id === bookingId ? { ...b, status: 'travelling' } : b),
      }));
    }, 2000);
  }, [showToast]);

  // ── MECHANIC ──────────────────────────────
  const updateMechanicStatus = useCallback((mechanicId: string, status: Mechanic['status']) => {
    setState(s => ({
      ...s,
      mechanics: s.mechanics.map(m => m.id === mechanicId ? { ...m, status } : m),
    }));
  }, []);

  // ── KHATA ──────────────────────────────────
  const addKhataEntry = useCallback((entry: Omit<KhataEntry, 'id'>) => {
    const newEntry: KhataEntry = { ...entry, id: `k${Date.now()}` };
    setState(s => ({ ...s, khataEntries: [newEntry, ...s.khataEntries] }));
  }, []);

  // ── NOTIFICATIONS ──────────────────────────
  const markNotificationRead = useCallback((id: string) => {
    setState(s => ({
      ...s,
      notifications: s.notifications.map(n => n.id === id ? { ...n, read: true } : n),
    }));
  }, []);

  // ── UI ─────────────────────────────────────
  const setActiveTab = useCallback((tab: string) => {
    setState(s => ({ ...s, activeTab: tab }));
  }, []);

  const setCurrentBooking = useCallback((booking: Partial<Booking> | null) => {
    setState(s => ({ ...s, currentBooking: booking }));
  }, []);

  const setBookingStep = useCallback((step: number) => {
    setState(s => ({ ...s, bookingStep: step }));
  }, []);

  const value: AppContextValue = {
    ...state,
    login, signup, logout,
    createBooking, updateBookingStatus, cancelBooking, rateBooking,
    updateMechanicStatus, acceptBooking,
    setActiveTab, showToast, setCurrentBooking, setBookingStep,
    markNotificationRead, addKhataEntry,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
